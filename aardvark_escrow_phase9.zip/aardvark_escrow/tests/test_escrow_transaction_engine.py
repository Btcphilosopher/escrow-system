"""Integration tests for the escrow transaction engine: fund, approve,
release, refund.

Run against real Postgres — this is where the row-locking, deadlock
avoidance, and idempotency guarantees actually get proven.
"""
import asyncio
import uuid

from httpx import AsyncClient

PASSWORD = "correct-horse-42"


async def _register(client: AsyncClient, email: str, full_name: str = "Test User") -> dict:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": PASSWORD, "full_name": full_name},
    )
    body = response.json()
    return {"token": body["access_token"], "user_id": body["user"]["id"]}


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


async def _deposit(client: AsyncClient, token: str, amount: str) -> None:
    response = await client.post(
        "/api/v1/wallet/deposit", headers=_headers(token), json={"amount": amount}
    )
    assert response.status_code == 200


async def _create_escrow(
    client: AsyncClient, payer_token: str, payee_email: str, amount: str = "500.00"
):
    return await client.post(
        "/api/v1/escrows",
        headers=_headers(payer_token),
        json={"payee_email": payee_email, "amount": amount, "description": "Test escrow"},
    )


async def _setup_funded_escrow(client: AsyncClient, suffix: str, amount: str = "500.00"):
    """Registers payer+payee, funds the payer's wallet, creates and funds
    an escrow. Returns (payer, payee, escrow_id).
    """
    payer = await _register(client, f"payer-{suffix}@example.com", "Payer")
    payee = await _register(client, f"payee-{suffix}@example.com", "Payee")
    await _deposit(client, payer["token"], "1000.00")

    create_response = await _create_escrow(
        client, payer["token"], f"payee-{suffix}@example.com", amount
    )
    escrow_id = create_response.json()["id"]

    fund_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    assert fund_response.status_code == 200
    return payer, payee, escrow_id


# ---------------------------------------------------------------- fund


async def test_fund_moves_status_to_in_progress_and_holds_funds(client: AsyncClient) -> None:
    payer, _payee, escrow_id = await _setup_funded_escrow(client, "f1")

    escrow_response = await client.get(
        f"/api/v1/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    body = escrow_response.json()
    assert body["status"] == "in_progress"
    assert body["funded_at"] is not None

    wallet_response = await client.get("/api/v1/wallet", headers=_headers(payer["token"]))
    wallet_body = wallet_response.json()
    assert wallet_body["balance"] == "1000.00"
    assert wallet_body["held_balance"] == "500.00"
    assert wallet_body["available_balance"] == "500.00"


async def test_fund_fails_with_insufficient_balance(client: AsyncClient) -> None:
    payer = await _register(client, "poor-payer@example.com", "Poor Payer")
    await _register(client, "poor-payee@example.com", "Payee")
    await _deposit(client, payer["token"], "10.00")

    create_response = await _create_escrow(
        client, payer["token"], "poor-payee@example.com", "500.00"
    )
    escrow_id = create_response.json()["id"]

    fund_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    assert fund_response.status_code == 422
    assert "Insufficient" in fund_response.json()["detail"]


async def test_only_payer_can_fund(client: AsyncClient) -> None:
    payer = await _register(client, "payer-auth@example.com", "Payer")
    payee = await _register(client, "payee-auth@example.com", "Payee")
    await _deposit(client, payer["token"], "1000.00")

    create_response = await _create_escrow(client, payer["token"], "payee-auth@example.com")
    escrow_id = create_response.json()["id"]

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payee["token"]), json={}
    )
    assert response.status_code == 403


async def test_cannot_fund_an_already_funded_escrow(client: AsyncClient) -> None:
    payer, _payee, escrow_id = await _setup_funded_escrow(client, "f2")

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    assert response.status_code == 422


async def test_fund_with_idempotency_key_is_not_double_applied(client: AsyncClient) -> None:
    payer = await _register(client, "payer-idem@example.com", "Payer")
    await _register(client, "payee-idem@example.com", "Payee")
    await _deposit(client, payer["token"], "1000.00")

    create_response = await _create_escrow(client, payer["token"], "payee-idem@example.com")
    escrow_id = create_response.json()["id"]
    key = str(uuid.uuid4())

    first = await client.post(
        f"/api/v1/escrows/{escrow_id}/fund",
        headers=_headers(payer["token"]),
        json={"idempotency_key": key},
    )
    second = await client.post(
        f"/api/v1/escrows/{escrow_id}/fund",
        headers=_headers(payer["token"]),
        json={"idempotency_key": key},
    )
    assert first.status_code == 200
    assert second.status_code == 200
    assert first.json()["status"] == second.json()["status"] == "in_progress"

    wallet_response = await client.get("/api/v1/wallet", headers=_headers(payer["token"]))
    assert wallet_response.json()["held_balance"] == "500.00"  # not double-held


# ------------------------------------------------------------- approve


async def test_approve_moves_to_awaiting_approval_with_no_money_movement(
    client: AsyncClient,
) -> None:
    payer, payee, escrow_id = await _setup_funded_escrow(client, "a1")

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payee["token"])
    )
    assert response.status_code == 200
    assert response.json()["status"] == "awaiting_approval"

    wallet_response = await client.get("/api/v1/wallet", headers=_headers(payer["token"]))
    assert wallet_response.json()["held_balance"] == "500.00"  # unchanged


async def test_only_payee_can_approve(client: AsyncClient) -> None:
    payer, _payee, escrow_id = await _setup_funded_escrow(client, "a2")

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payer["token"])
    )
    assert response.status_code == 403


# ------------------------------------------------------------- release


async def test_release_transfers_funds_to_payee(client: AsyncClient) -> None:
    payer, payee, escrow_id = await _setup_funded_escrow(client, "r1", amount="300.00")
    await client.post(f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payee["token"]))

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/release", headers=_headers(payer["token"]), json={}
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "released"
    assert body["released_at"] is not None

    payer_wallet = await client.get("/api/v1/wallet", headers=_headers(payer["token"]))
    payee_wallet = await client.get("/api/v1/wallet", headers=_headers(payee["token"]))

    assert payer_wallet.json()["balance"] == "700.00"  # 1000 - 300
    assert payer_wallet.json()["held_balance"] == "0.00"
    assert payee_wallet.json()["balance"] == "300.00"


async def test_only_payer_can_release_from_awaiting_approval(client: AsyncClient) -> None:
    payer, payee, escrow_id = await _setup_funded_escrow(client, "r2")
    await client.post(f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payee["token"]))

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/release", headers=_headers(payee["token"]), json={}
    )
    assert response.status_code == 403


async def test_cannot_release_before_approval(client: AsyncClient) -> None:
    payer, _payee, escrow_id = await _setup_funded_escrow(client, "r3")

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/release", headers=_headers(payer["token"]), json={}
    )
    assert response.status_code == 422


async def test_release_with_idempotency_key_is_not_double_applied(client: AsyncClient) -> None:
    payer, payee, escrow_id = await _setup_funded_escrow(client, "r4", amount="200.00")
    await client.post(f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payee["token"]))
    key = str(uuid.uuid4())

    first = await client.post(
        f"/api/v1/escrows/{escrow_id}/release",
        headers=_headers(payer["token"]),
        json={"idempotency_key": key},
    )
    second = await client.post(
        f"/api/v1/escrows/{escrow_id}/release",
        headers=_headers(payer["token"]),
        json={"idempotency_key": key},
    )
    assert first.status_code == 200
    assert second.status_code == 200

    payee_wallet = await client.get("/api/v1/wallet", headers=_headers(payee["token"]))
    assert payee_wallet.json()["balance"] == "200.00"  # not double-credited


# -------------------------------------------------------------- refund


async def test_refund_returns_hold_without_touching_balance(client: AsyncClient) -> None:
    payer, payee, escrow_id = await _setup_funded_escrow(client, "rf1", amount="400.00")

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/refund", headers=_headers(payee["token"]), json={}
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "closed"
    assert body["refunded_at"] is not None

    payer_wallet = await client.get("/api/v1/wallet", headers=_headers(payer["token"]))
    assert payer_wallet.json()["balance"] == "1000.00"  # never left
    assert payer_wallet.json()["held_balance"] == "0.00"
    assert payer_wallet.json()["available_balance"] == "1000.00"

    payee_wallet = await client.get("/api/v1/wallet", headers=_headers(payee["token"]))
    assert payee_wallet.json()["balance"] == "0.00"


async def test_only_payee_can_refund_before_a_dispute(client: AsyncClient) -> None:
    payer, _payee, escrow_id = await _setup_funded_escrow(client, "rf2")

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/refund", headers=_headers(payer["token"]), json={}
    )
    assert response.status_code == 403


async def test_refund_lands_on_closed_not_refunded(client: AsyncClient) -> None:
    """REFUNDED and CLOSED collapse into one step, mirroring the
    CREATED->AWAITING_PAYMENT and FUNDED->IN_PROGRESS collapses.
    """
    _payer, payee, escrow_id = await _setup_funded_escrow(client, "rf3")

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/refund", headers=_headers(payee["token"]), json={}
    )
    assert response.json()["status"] == "closed"


async def test_refund_with_idempotency_key_is_not_double_applied(client: AsyncClient) -> None:
    payer, payee, escrow_id = await _setup_funded_escrow(client, "rf4", amount="150.00")
    key = str(uuid.uuid4())

    first = await client.post(
        f"/api/v1/escrows/{escrow_id}/refund",
        headers=_headers(payee["token"]),
        json={"idempotency_key": key},
    )
    second = await client.post(
        f"/api/v1/escrows/{escrow_id}/refund",
        headers=_headers(payee["token"]),
        json={"idempotency_key": key},
    )
    assert first.status_code == 200
    assert second.status_code == 200

    payer_wallet = await client.get("/api/v1/wallet", headers=_headers(payer["token"]))
    assert payer_wallet.json()["held_balance"] == "0.00"  # not double-decremented


async def test_cannot_refund_a_released_escrow(client: AsyncClient) -> None:
    payer, payee, escrow_id = await _setup_funded_escrow(client, "rf5")
    await client.post(f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payee["token"]))
    await client.post(
        f"/api/v1/escrows/{escrow_id}/release", headers=_headers(payer["token"]), json={}
    )

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/refund", headers=_headers(payee["token"]), json={}
    )
    assert response.status_code == 422


# --------------------------------------------------- full lifecycle


async def test_full_happy_path_lifecycle(client: AsyncClient) -> None:
    payer = await _register(client, "lifecycle-payer@example.com", "Payer")
    payee = await _register(client, "lifecycle-payee@example.com", "Payee")
    await _deposit(client, payer["token"], "1000.00")

    create_response = await _create_escrow(
        client, payer["token"], "lifecycle-payee@example.com", "600.00"
    )
    escrow_id = create_response.json()["id"]
    assert create_response.json()["status"] == "awaiting_payment"

    fund_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    assert fund_response.json()["status"] == "in_progress"

    approve_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payee["token"])
    )
    assert approve_response.json()["status"] == "awaiting_approval"

    release_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/release", headers=_headers(payer["token"]), json={}
    )
    assert release_response.json()["status"] == "released"

    payer_wallet = await client.get("/api/v1/wallet", headers=_headers(payer["token"]))
    payee_wallet = await client.get("/api/v1/wallet", headers=_headers(payee["token"]))
    assert payer_wallet.json()["balance"] == "400.00"
    assert payer_wallet.json()["held_balance"] == "0.00"
    assert payee_wallet.json()["balance"] == "600.00"


# ------------------------------------------------------- concurrency


async def test_concurrent_releases_do_not_deadlock_with_reversed_wallet_roles(
    client: AsyncClient,
) -> None:
    """Two escrows between the same two users with payer/payee reversed,
    released concurrently. If wallet locking didn't use a fixed global
    order, this is exactly the scenario that can deadlock: operation A
    locks (wallet_1, wallet_2) while operation B locks (wallet_2, wallet_1)
    at the same time.
    """
    alice = await _register(client, "alice-deadlock@example.com", "Alice")
    bob = await _register(client, "bob-deadlock@example.com", "Bob")
    await _deposit(client, alice["token"], "1000.00")
    await _deposit(client, bob["token"], "1000.00")

    # Escrow 1: Alice pays Bob. Escrow 2: Bob pays Alice.
    escrow1_response = await _create_escrow(
        client, alice["token"], "bob-deadlock@example.com", "100.00"
    )
    escrow2_response = await _create_escrow(
        client, bob["token"], "alice-deadlock@example.com", "150.00"
    )
    escrow1 = escrow1_response.json()["id"]
    escrow2 = escrow2_response.json()["id"]

    await client.post(f"/api/v1/escrows/{escrow1}/fund", headers=_headers(alice["token"]), json={})
    await client.post(f"/api/v1/escrows/{escrow2}/fund", headers=_headers(bob["token"]), json={})
    await client.post(f"/api/v1/escrows/{escrow1}/approve", headers=_headers(bob["token"]))
    await client.post(f"/api/v1/escrows/{escrow2}/approve", headers=_headers(alice["token"]))

    async def _release(escrow_id: str, payer_token: str):
        return await client.post(
            f"/api/v1/escrows/{escrow_id}/release", headers=_headers(payer_token), json={}
        )

    results = await asyncio.wait_for(
        asyncio.gather(
            _release(escrow1, alice["token"]),
            _release(escrow2, bob["token"]),
        ),
        timeout=10,
    )
    assert all(r.status_code == 200 for r in results)

    alice_wallet = await client.get("/api/v1/wallet", headers=_headers(alice["token"]))
    bob_wallet = await client.get("/api/v1/wallet", headers=_headers(bob["token"]))
    # Alice: 1000 - 100 (paid to bob) + 150 (received from bob) = 1050
    assert alice_wallet.json()["balance"] == "1050.00"
    # Bob: 1000 - 150 (paid to alice) + 100 (received from alice) = 950
    assert bob_wallet.json()["balance"] == "950.00"
