"""Tests for the Phase 8 background worker task implementations.

Each Celery task follows a sync-wrapper/async-impl split (see
app.workers.tasks's module docstring) specifically so the real logic can
be tested directly with pytest-asyncio against a real database, without
needing a running Celery worker or calling asyncio.run() from inside an
already-running event loop (which would raise).
"""
from datetime import UTC, datetime, timedelta
from decimal import Decimal

from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.entities.audit import AuditAction
from app.domain.entities.audit import AuditLog as AuditLogEntity
from app.domain.entities.enums import NotificationStatus
from app.domain.entities.escrow import Escrow
from app.domain.entities.notification import Notification
from app.domain.entities.wallet import Wallet
from app.workers.celery_app import celery_app
from app.workers.tasks.escrow_expiry import _detect_expired_escrows
from app.workers.tasks.notifications import _deliver_pending_notifications
from app.workers.tasks.reconciliation import _reconcile_wallets
from app.workers.tasks.statistics import _generate_platform_statistics, compute_platform_statistics

PASSWORD = "correct-horse-42"


async def _register(client: AsyncClient, email: str, full_name: str = "Test User") -> dict:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": PASSWORD, "full_name": full_name},
    )
    body = response.json()
    return {"token": body["access_token"], "user_id": body["user"]["id"]}


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


# ------------------------------------------------------ task registration


def test_all_tasks_are_registered_with_celery() -> None:
    assert "notifications.deliver_pending" in celery_app.tasks
    assert "escrows.detect_expired" in celery_app.tasks
    assert "reconciliation.daily_wallet_reconciliation" in celery_app.tasks
    assert "statistics.generate_platform_statistics" in celery_app.tasks


def test_beat_schedule_has_all_four_periodic_tasks() -> None:
    schedule = celery_app.conf.beat_schedule
    assert set(schedule.keys()) == {
        "deliver-pending-notifications",
        "detect-expired-escrows",
        "daily-wallet-reconciliation",
        "generate-platform-statistics",
    }


# ------------------------------------------------------ notification delivery


async def test_deliver_pending_notifications_marks_them_sent(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer = await _register(client, "worker-payer1@example.com", "Payer")
    await _register(client, "worker-payee1@example.com", "Payee")

    # Creating an escrow writes a PENDING notification to the payee
    # (Phase 7).
    await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "worker-payee1@example.com",
            "amount": "50.00",
            "description": "x",
        },
    )

    result = await _deliver_pending_notifications()
    assert result["sent"] >= 1
    assert result["failed"] == 0

    remaining_pending = await db_session.execute(
        select(Notification).where(Notification.status == NotificationStatus.PENDING)
    )
    assert remaining_pending.scalars().first() is None


async def test_deliver_pending_notifications_is_a_no_op_when_none_pending(
    db_session: AsyncSession,
) -> None:
    result = await _deliver_pending_notifications()
    assert result == {"sent": 0, "failed": 0}


# ------------------------------------------------------ expired escrow detection


async def test_detect_expired_escrows_cancels_unfunded_ones_past_deadline(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer = await _register(client, "worker-payer2@example.com", "Payer")
    await _register(client, "worker-payee2@example.com", "Payee")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "worker-payee2@example.com",
            "amount": "75.00",
            "description": "x",
            "expires_at": (datetime.now(UTC) + timedelta(minutes=5)).isoformat(),
        },
    )
    escrow_id = create_response.json()["id"]

    # Backdate expires_at directly — the API validates it must be in the
    # future at creation time, so this simulates time having passed.
    result = await db_session.execute(select(Escrow).where(Escrow.id == escrow_id))
    escrow = result.scalar_one()
    escrow.expires_at = datetime.now(UTC) - timedelta(minutes=1)
    await db_session.commit()

    task_result = await _detect_expired_escrows()
    assert task_result["expired"] == 1
    assert task_result["failed"] == 0

    escrow_response = await client.get(
        f"/api/v1/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert escrow_response.json()["status"] == "cancelled"


async def test_detect_expired_escrows_ignores_funded_escrows(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer = await _register(client, "worker-payer3@example.com", "Payer")
    await _register(client, "worker-payee3@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "500.00"}
    )

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "worker-payee3@example.com",
            "amount": "100.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )

    result = await db_session.execute(select(Escrow).where(Escrow.id == escrow_id))
    escrow = result.scalar_one()
    escrow.expires_at = datetime.now(UTC) - timedelta(minutes=1)
    await db_session.commit()

    task_result = await _detect_expired_escrows()
    assert task_result["expired"] == 0

    escrow_response = await client.get(
        f"/api/v1/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert escrow_response.json()["status"] == "in_progress"  # untouched


async def test_detect_expired_escrows_ignores_escrows_without_a_deadline(
    client: AsyncClient,
) -> None:
    payer = await _register(client, "worker-payer4@example.com", "Payer")
    await _register(client, "worker-payee4@example.com", "Payee")
    await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "worker-payee4@example.com",
            "amount": "20.00",
            "description": "no deadline set",
        },
    )

    result = await _detect_expired_escrows()
    assert result["expired"] == 0


# ------------------------------------------------------ wallet reconciliation


async def test_reconciliation_finds_no_mismatch_in_healthy_state(
    client: AsyncClient,
) -> None:
    payer = await _register(client, "worker-payer5@example.com", "Payer")
    payee = await _register(client, "worker-payee5@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "1000.00"}
    )

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "worker-payee5@example.com",
            "amount": "400.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    await client.post(
        f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payee["token"])
    )
    await client.post(
        f"/api/v1/escrows/{escrow_id}/release", headers=_headers(payer["token"]), json={}
    )

    result = await _reconcile_wallets()
    assert result["checked"] >= 2
    assert result["mismatches"] == 0


async def test_reconciliation_detects_a_tampered_balance(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer = await _register(client, "worker-payer6@example.com", "Payer")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "100.00"}
    )

    # Directly corrupt the balance, bypassing the ledger entirely --
    # simulating the kind of drift reconciliation exists to catch.
    result = await db_session.execute(
        select(Wallet).where(Wallet.user_id == payer["user_id"])
    )
    wallet = result.scalar_one()
    wallet.balance = Decimal("999.99")
    await db_session.commit()

    task_result = await _reconcile_wallets()
    assert task_result["mismatches"] >= 1

    audit_result = await db_session.execute(
        select(AuditLogEntity).where(
            AuditLogEntity.action == AuditAction.WALLET_RECONCILIATION_MISMATCH,
            AuditLogEntity.resource_id == wallet.id,
        )
    )
    assert audit_result.scalar_one_or_none() is not None


async def test_reconciliation_held_balance_check_uses_live_escrow_state(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    """Corrupting held_balance directly (not via a real fund operation)
    must be caught by the held-balance check specifically, proving it's
    genuinely comparing against live escrow state and not just trusting
    the wallet row.
    """
    payer = await _register(client, "worker-payer7@example.com", "Payer")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "100.00"}
    )

    result = await db_session.execute(
        select(Wallet).where(Wallet.user_id == payer["user_id"])
    )
    wallet = result.scalar_one()
    wallet.held_balance = Decimal("50.00")  # no escrow actually holds this
    await db_session.commit()

    task_result = await _reconcile_wallets()
    assert task_result["mismatches"] >= 1


# ------------------------------------------------------ statistics


async def test_compute_platform_statistics_reflects_real_data(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer = await _register(client, "worker-payer8@example.com", "Payer")
    await _register(client, "worker-payee8@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "300.00"}
    )
    await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "worker-payee8@example.com",
            "amount": "150.00",
            "description": "x",
        },
    )

    stats = await compute_platform_statistics(db_session)

    assert stats["total_users"] >= 2
    assert stats["escrow_counts_by_status"].get("awaiting_payment", 0) >= 1
    assert "total_released_volume" in stats
    assert "total_wallet_balance" in stats


async def test_compute_platform_statistics_counts_released_volume(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer = await _register(client, "worker-payer9@example.com", "Payer")
    payee = await _register(client, "worker-payee9@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "500.00"}
    )
    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "worker-payee9@example.com",
            "amount": "220.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    await client.post(
        f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payee["token"])
    )
    await client.post(
        f"/api/v1/escrows/{escrow_id}/release", headers=_headers(payer["token"]), json={}
    )

    stats = await compute_platform_statistics(db_session)
    assert Decimal(stats["total_released_volume"]) >= Decimal("220.00")


async def test_generate_platform_statistics_wrapper_opens_its_own_session(
    client: AsyncClient,
) -> None:
    """Exercises the async wrapper the Celery task delegates to (not the
    sync task itself — see this module's docstring for why).
    """
    await _register(client, "worker-stats-wrapper@example.com", "Someone")

    stats = await _generate_platform_statistics()
    assert stats["total_users"] >= 1
