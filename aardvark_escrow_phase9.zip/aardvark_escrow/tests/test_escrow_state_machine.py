"""Unit tests for EscrowStateMachine.

Pure domain logic, no database — these construct bare `Escrow` instances
in memory and drive the state machine directly. Every legal edge and
every illegal edge worth naming gets its own assertion, since this class
is the single gate every money-moving operation in Phase 6 will pass
through.
"""
import uuid

import pytest

from app.core.exceptions import InvalidStateTransitionError
from app.domain.entities.enums import EscrowStatus
from app.domain.entities.escrow import Escrow
from app.domain.services.escrow_state_machine import EscrowStateMachine

ALL_STATUSES = list(EscrowStatus)

# The complete legal transition graph, mirrored here independently of
# the implementation so a change to _LEGAL_TRANSITIONS is caught by a
# test failure rather than by both drifting together silently.
EXPECTED_LEGAL_EDGES = {
    (EscrowStatus.CREATED, EscrowStatus.AWAITING_PAYMENT),
    (EscrowStatus.CREATED, EscrowStatus.CANCELLED),
    (EscrowStatus.AWAITING_PAYMENT, EscrowStatus.FUNDED),
    (EscrowStatus.AWAITING_PAYMENT, EscrowStatus.CANCELLED),
    (EscrowStatus.FUNDED, EscrowStatus.IN_PROGRESS),
    (EscrowStatus.FUNDED, EscrowStatus.DISPUTED),
    (EscrowStatus.FUNDED, EscrowStatus.REFUNDED),
    (EscrowStatus.IN_PROGRESS, EscrowStatus.AWAITING_APPROVAL),
    (EscrowStatus.IN_PROGRESS, EscrowStatus.DISPUTED),
    (EscrowStatus.IN_PROGRESS, EscrowStatus.REFUNDED),
    (EscrowStatus.AWAITING_APPROVAL, EscrowStatus.RELEASED),
    (EscrowStatus.AWAITING_APPROVAL, EscrowStatus.DISPUTED),
    (EscrowStatus.AWAITING_APPROVAL, EscrowStatus.REFUNDED),
    (EscrowStatus.DISPUTED, EscrowStatus.RELEASED),
    (EscrowStatus.DISPUTED, EscrowStatus.REFUNDED),
    (EscrowStatus.REFUNDED, EscrowStatus.CLOSED),
}


def _make_escrow(status: EscrowStatus) -> Escrow:
    escrow = Escrow(
        payer_id=uuid.uuid4(),
        payee_id=uuid.uuid4(),
        amount=100,
        description="Test escrow",
    )
    escrow.id = uuid.uuid4()
    escrow.status = status
    return escrow


def test_every_pair_matches_the_expected_graph_exactly() -> None:
    """Exhaustively checks all 100 (10x10) status pairs against the
    hand-written expected graph above, so an accidental widening or
    narrowing of _LEGAL_TRANSITIONS anywhere is caught immediately.
    """
    for from_status in ALL_STATUSES:
        for to_status in ALL_STATUSES:
            expected = (from_status, to_status) in EXPECTED_LEGAL_EDGES
            actual = EscrowStateMachine.can_transition(from_status, to_status)
            assert actual == expected, f"{from_status} -> {to_status}"


@pytest.mark.parametrize(("from_status", "to_status"), sorted(EXPECTED_LEGAL_EDGES, key=str))
def test_legal_transition_succeeds_and_returns_matching_event(
    from_status: EscrowStatus, to_status: EscrowStatus
) -> None:
    escrow = _make_escrow(from_status)
    actor_id = uuid.uuid4()

    event = EscrowStateMachine.transition(
        escrow, to_status, actor_id=actor_id, reason="test reason"
    )

    assert escrow.status == to_status
    assert event.escrow_id == escrow.id
    assert event.from_status == from_status
    assert event.to_status == to_status
    assert event.actor_id == actor_id
    assert event.reason == "test reason"


def test_terminal_statuses_allow_no_further_transitions() -> None:
    for terminal_status in (EscrowStatus.RELEASED, EscrowStatus.CANCELLED, EscrowStatus.CLOSED):
        for to_status in ALL_STATUSES:
            assert EscrowStateMachine.can_transition(terminal_status, to_status) is False


def test_illegal_transition_raises_with_useful_message() -> None:
    escrow = _make_escrow(EscrowStatus.CREATED)

    with pytest.raises(InvalidStateTransitionError) as exc_info:
        EscrowStateMachine.transition(escrow, EscrowStatus.RELEASED)

    assert "CREATED" in str(exc_info.value) or "created" in str(exc_info.value)
    assert "released" in str(exc_info.value).lower()
    # A failed transition must not mutate the escrow at all.
    assert escrow.status == EscrowStatus.CREATED


def test_cannot_skip_from_funded_directly_to_released() -> None:
    escrow = _make_escrow(EscrowStatus.FUNDED)
    with pytest.raises(InvalidStateTransitionError):
        EscrowStateMachine.transition(escrow, EscrowStatus.RELEASED)


def test_cannot_re_fund_an_already_funded_escrow() -> None:
    escrow = _make_escrow(EscrowStatus.FUNDED)
    with pytest.raises(InvalidStateTransitionError):
        EscrowStateMachine.transition(escrow, EscrowStatus.FUNDED)


def test_cannot_cancel_after_funding() -> None:
    escrow = _make_escrow(EscrowStatus.FUNDED)
    with pytest.raises(InvalidStateTransitionError):
        EscrowStateMachine.transition(escrow, EscrowStatus.CANCELLED)


def test_disputed_can_resolve_to_either_release_or_refund() -> None:
    released = _make_escrow(EscrowStatus.DISPUTED)
    EscrowStateMachine.transition(released, EscrowStatus.RELEASED)
    assert released.status == EscrowStatus.RELEASED

    refunded = _make_escrow(EscrowStatus.DISPUTED)
    EscrowStateMachine.transition(refunded, EscrowStatus.REFUNDED)
    assert refunded.status == EscrowStatus.REFUNDED


def test_dispute_reachable_from_funded_in_progress_and_awaiting_approval() -> None:
    for starting_status in (
        EscrowStatus.FUNDED,
        EscrowStatus.IN_PROGRESS,
        EscrowStatus.AWAITING_APPROVAL,
    ):
        escrow = _make_escrow(starting_status)
        EscrowStateMachine.transition(escrow, EscrowStatus.DISPUTED)
        assert escrow.status == EscrowStatus.DISPUTED


@pytest.mark.parametrize(
    ("to_status", "timestamp_attr"),
    [
        (EscrowStatus.FUNDED, "funded_at"),
        (EscrowStatus.RELEASED, "released_at"),
        (EscrowStatus.REFUNDED, "refunded_at"),
        (EscrowStatus.CANCELLED, "cancelled_at"),
    ],
)
def test_milestone_timestamp_is_set_on_the_matching_transition(
    to_status: EscrowStatus, timestamp_attr: str
) -> None:
    from_status = next(
        s for (s, t) in EXPECTED_LEGAL_EDGES if t == to_status and s != to_status
    )
    escrow = _make_escrow(from_status)
    assert getattr(escrow, timestamp_attr) is None

    EscrowStateMachine.transition(escrow, to_status)

    assert getattr(escrow, timestamp_attr) is not None


def test_non_milestone_transition_does_not_set_any_timestamp() -> None:
    escrow = _make_escrow(EscrowStatus.CREATED)
    EscrowStateMachine.transition(escrow, EscrowStatus.AWAITING_PAYMENT)

    for attr in ("funded_at", "released_at", "refunded_at", "cancelled_at"):
        assert getattr(escrow, attr) is None


def test_from_status_is_none_only_for_manually_constructed_creation_events() -> None:
    """EscrowStateMachine.transition always requires a real starting
    status — the CREATED event's from_status=None is built directly by
    EscrowService, not by this class. Confirms transition() never
    produces a None from_status itself.
    """
    escrow = _make_escrow(EscrowStatus.CREATED)
    event = EscrowStateMachine.transition(escrow, EscrowStatus.AWAITING_PAYMENT)
    assert event.from_status is not None
