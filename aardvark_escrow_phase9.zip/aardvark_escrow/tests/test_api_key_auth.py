"""Integration tests for API-key authentication.

No CRUD endpoint issues API keys yet (see app/security/api_keys.py's
docstring for why), so this seeds an APIKey row directly via the ORM to
exercise the `X-API-Key` header path through `get_current_user` — the
same dependency `/users/me` and every future protected endpoint use.
"""
from datetime import UTC, datetime, timedelta

from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.entities.api_key import APIKey
from app.domain.entities.enums import APIKeyStatus
from app.domain.entities.user import User
from app.security.api_keys import generate_api_key, hash_api_key
from app.security.password import hash_password


async def _seed_user_with_api_key(
    db_session: AsyncSession, *, status: APIKeyStatus = APIKeyStatus.ACTIVE, expired: bool = False
) -> tuple[User, str]:
    user = User(
        email="integration@example.com",
        hashed_password=hash_password("irrelevant-for-this-test"),
        full_name="Integration Tester",
    )
    db_session.add(user)
    await db_session.flush()

    raw_key, prefix = generate_api_key()
    api_key = APIKey(
        user_id=user.id,
        name="CI key",
        key_prefix=prefix,
        hashed_key=hash_api_key(raw_key),
        status=status,
        scopes=["escrow:read"],
        expires_at=(datetime.now(UTC) - timedelta(days=1)) if expired else None,
    )
    db_session.add(api_key)
    await db_session.commit()
    return user, raw_key


async def test_valid_api_key_authenticates(client: AsyncClient, db_session: AsyncSession) -> None:
    user, raw_key = await _seed_user_with_api_key(db_session)

    response = await client.get("/api/v1/users/me", headers={"X-API-Key": raw_key})
    assert response.status_code == 200
    assert response.json()["email"] == user.email


async def test_revoked_api_key_is_rejected(client: AsyncClient, db_session: AsyncSession) -> None:
    _, raw_key = await _seed_user_with_api_key(db_session, status=APIKeyStatus.REVOKED)

    response = await client.get("/api/v1/users/me", headers={"X-API-Key": raw_key})
    assert response.status_code == 401


async def test_expired_api_key_is_rejected(client: AsyncClient, db_session: AsyncSession) -> None:
    _, raw_key = await _seed_user_with_api_key(db_session, expired=True)

    response = await client.get("/api/v1/users/me", headers={"X-API-Key": raw_key})
    assert response.status_code == 401


async def test_unknown_api_key_is_rejected(client: AsyncClient) -> None:
    response = await client.get(
        "/api/v1/users/me", headers={"X-API-Key": "ae_live_totally-made-up-key"}
    )
    assert response.status_code == 401


async def test_api_key_updates_last_used_at(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    user, raw_key = await _seed_user_with_api_key(db_session)

    await client.get("/api/v1/users/me", headers={"X-API-Key": raw_key})

    result = await db_session.execute(select(APIKey).where(APIKey.user_id == user.id))
    api_key_row = result.scalar_one()
    assert api_key_row.last_used_at is not None
