"""Tests for the UnitOfWork context manager itself.

The service-layer tests (test_auth.py, test_wallet.py) already exercise
UnitOfWork indirectly on every call; these confirm its rollback-on-
exception and no-implicit-commit behaviour directly.
"""
import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.unit_of_work import UnitOfWork
from app.domain.entities.user import User


async def test_uow_rolls_back_on_exception(db_session: AsyncSession) -> None:
    with pytest.raises(RuntimeError):
        async with UnitOfWork(db_session) as uow:
            user = User(email="rollback@example.com", hashed_password="x", full_name="X")
            uow.users.add(user)
            await uow.session.flush()
            raise RuntimeError("simulated failure mid-transaction")

    result = await db_session.execute(
        select(User).where(User.email == "rollback@example.com")
    )
    assert result.scalar_one_or_none() is None


async def test_uow_does_not_auto_commit_on_clean_exit(db_session: AsyncSession) -> None:
    async with UnitOfWork(db_session) as uow:
        user = User(email="no-autocommit@example.com", hashed_password="x", full_name="X")
        uow.users.add(user)
        await uow.session.flush()
        # Deliberately not calling uow.commit().

    await db_session.rollback()
    result = await db_session.execute(
        select(User).where(User.email == "no-autocommit@example.com")
    )
    assert result.scalar_one_or_none() is None


async def test_uow_persists_when_commit_is_called(db_session: AsyncSession) -> None:
    async with UnitOfWork(db_session) as uow:
        user = User(email="committed@example.com", hashed_password="x", full_name="X")
        uow.users.add(user)
        await uow.commit()

    result = await db_session.execute(
        select(User).where(User.email == "committed@example.com")
    )
    assert result.scalar_one_or_none() is not None
