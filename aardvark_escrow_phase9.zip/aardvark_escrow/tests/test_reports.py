"""Integration tests for the /reports endpoints and the underlying
ReportService — PDF/CSV generation against real data.

PDF assertions are necessarily light (checking the magic bytes and a
sane minimum size) since PDF is a binary format; the real correctness
check is that the underlying data queries return the right rows, which
is covered thoroughly by asserting on CSV content (plain text, directly
inspectable) and by the JSON-returning endpoints these reports pull from
elsewhere in the suite.
"""
import csv
import io
from datetime import UTC, datetime, timedelta

from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.entities.enums import UserRole
from app.domain.entities.user import User
from app.security.password import hash_password

PASSWORD = "correct-horse-42"


async def _register(client: AsyncClient, email: str, full_name: str = "Test User") -> dict:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": PASSWORD, "full_name": full_name},
    )
    body = response.json()
    return {"token": body["access_token"], "user_id": body["user"]["id"]}


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


async def _make_admin_and_login(client: AsyncClient, db_session: AsyncSession, email: str) -> str:
    user = User(
        email=email,
        hashed_password=hash_password(PASSWORD),
        full_name="Admin",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()
    response = await client.post(
        "/api/v1/auth/login", json={"email": email, "password": PASSWORD}
    )
    return str(response.json()["access_token"])


def _is_pdf(content: bytes) -> bool:
    return content.startswith(b"%PDF-")


# ------------------------------------------------------- escrow history


async def test_escrow_history_report_is_a_pdf(client: AsyncClient) -> None:
    payer = await _register(client, "rpt-payer1@example.com", "Payer")
    await _register(client, "rpt-payee1@example.com", "Payee")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={"payee_email": "rpt-payee1@example.com", "amount": "100.00", "description": "x"},
    )
    escrow_id = create_response.json()["id"]

    response = await client.get(
        f"/api/v1/reports/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert _is_pdf(response.content)
    assert len(response.content) > 500


async def test_escrow_history_report_covers_full_lifecycle(client: AsyncClient) -> None:
    payer = await _register(client, "rpt-payer2@example.com", "Payer")
    payee = await _register(client, "rpt-payee2@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "500.00"}
    )

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={"payee_email": "rpt-payee2@example.com", "amount": "200.00", "description": "x"},
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    await client.post(
        f"/api/v1/escrows/{escrow_id}/approve", headers=_headers(payee["token"])
    )
    await client.post(
        f"/api/v1/escrows/{escrow_id}/release", headers=_headers(payer["token"]), json={}
    )

    response = await client.get(
        f"/api/v1/reports/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert response.status_code == 200
    assert _is_pdf(response.content)
    # A report covering 5 events + 2 transactions should be meaningfully
    # larger than a bare, empty one.
    assert len(response.content) > 2000


async def test_escrow_history_report_hidden_from_unrelated_users(client: AsyncClient) -> None:
    payer = await _register(client, "rpt-payer3@example.com", "Payer")
    await _register(client, "rpt-payee3@example.com", "Payee")
    outsider = await _register(client, "rpt-outsider3@example.com", "Outsider")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={"payee_email": "rpt-payee3@example.com", "amount": "50.00", "description": "x"},
    )
    escrow_id = create_response.json()["id"]

    response = await client.get(
        f"/api/v1/reports/escrows/{escrow_id}", headers=_headers(outsider["token"])
    )
    assert response.status_code == 404


async def test_escrow_history_report_requires_authentication(client: AsyncClient) -> None:
    response = await client.get(
        "/api/v1/reports/escrows/00000000-0000-0000-0000-000000000000"
    )
    assert response.status_code == 401


# ---------------------------------------------------------- wallet statement


async def test_wallet_statement_pdf_by_default(client: AsyncClient) -> None:
    payer = await _register(client, "rpt-payer4@example.com", "Payer")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "100.00"}
    )

    response = await client.get(
        "/api/v1/reports/wallet/statement", headers=_headers(payer["token"])
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert _is_pdf(response.content)


async def test_wallet_statement_csv_contains_the_right_transactions(
    client: AsyncClient,
) -> None:
    payer = await _register(client, "rpt-payer5@example.com", "Payer")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "150.00"}
    )
    await client.post(
        "/api/v1/wallet/withdraw", headers=_headers(payer["token"]), json={"amount": "40.00"}
    )

    response = await client.get(
        "/api/v1/reports/wallet/statement",
        headers=_headers(payer["token"]),
        params={"format": "csv"},
    )
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/csv")

    reader = csv.DictReader(io.StringIO(response.text))
    rows = list(reader)
    assert len(rows) == 2
    assert {row["type"] for row in rows} == {"deposit", "withdrawal"}
    amounts = {row["amount"] for row in rows}
    assert "150.00" in amounts
    assert "-40.00" in amounts


async def test_wallet_statement_respects_date_range(client: AsyncClient) -> None:
    payer = await _register(client, "rpt-payer6@example.com", "Payer")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "10.00"}
    )

    future_start = (datetime.now(UTC) + timedelta(days=1)).isoformat()
    response = await client.get(
        "/api/v1/reports/wallet/statement",
        headers=_headers(payer["token"]),
        params={"format": "csv", "start_date": future_start},
    )
    reader = csv.DictReader(io.StringIO(response.text))
    assert list(reader) == []


async def test_wallet_statement_only_shows_own_transactions(client: AsyncClient) -> None:
    payer1 = await _register(client, "rpt-payer7a@example.com", "Payer1")
    payer2 = await _register(client, "rpt-payer7b@example.com", "Payer2")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer1["token"]), json={"amount": "77.00"}
    )

    response = await client.get(
        "/api/v1/reports/wallet/statement",
        headers=_headers(payer2["token"]),
        params={"format": "csv"},
    )
    reader = csv.DictReader(io.StringIO(response.text))
    assert list(reader) == []


# ---------------------------------------------------------- audit export


async def test_audit_export_requires_admin(client: AsyncClient) -> None:
    token = (await _register(client, "rpt-regular@example.com"))["token"]
    response = await client.get("/api/v1/reports/audit", headers=_headers(token))
    assert response.status_code == 403


async def test_audit_export_csv_contains_real_actions(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    await _register(client, "rpt-audited@example.com")
    admin_token = await _make_admin_and_login(client, db_session, "rpt-admin1@example.com")

    response = await client.get(
        "/api/v1/reports/audit", headers=_headers(admin_token), params={"format": "csv"}
    )
    assert response.status_code == 200
    reader = csv.DictReader(io.StringIO(response.text))
    actions = [row["action"] for row in reader]
    assert "user.registered" in actions


async def test_audit_export_pdf(client: AsyncClient, db_session: AsyncSession) -> None:
    await _register(client, "rpt-audited2@example.com")
    admin_token = await _make_admin_and_login(client, db_session, "rpt-admin2@example.com")

    response = await client.get(
        "/api/v1/reports/audit", headers=_headers(admin_token), params={"format": "pdf"}
    )
    assert response.status_code == 200
    assert _is_pdf(response.content)


# ---------------------------------------------------- operator activity


async def test_operator_activity_requires_admin(client: AsyncClient) -> None:
    token = (await _register(client, "rpt-regular2@example.com"))["token"]
    response = await client.get("/api/v1/reports/operator-activity", headers=_headers(token))
    assert response.status_code == 403


async def test_operator_activity_only_includes_admin_actions(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer = await _register(client, "rpt-op-payer@example.com", "Payer")
    await _register(client, "rpt-op-payee@example.com", "Payee")
    admin_token = await _make_admin_and_login(client, db_session, "rpt-admin3@example.com")

    # A regular user's action (escrow creation) should NOT show up in
    # operator activity, even though it writes an AuditLog row.
    await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={"payee_email": "rpt-op-payee@example.com", "amount": "10.00", "description": "x"},
    )

    # An admin action (resolving... well, there's no dispute here, so
    # let's just check the regular action is excluded).
    response = await client.get(
        "/api/v1/reports/operator-activity",
        headers=_headers(admin_token),
        params={"format": "csv"},
    )
    reader = csv.DictReader(io.StringIO(response.text))
    actions = [row["action"] for row in reader]
    assert "escrow.created" not in actions


async def test_operator_activity_includes_dispute_resolution(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer = await _register(client, "rpt-op2-payer@example.com", "Payer")
    await _register(client, "rpt-op2-payee@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "300.00"}
    )
    admin_token = await _make_admin_and_login(client, db_session, "rpt-admin4@example.com")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "rpt-op2-payee@example.com",
            "amount": "300.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    dispute_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/dispute",
        headers=_headers(payer["token"]),
        json={"reason": "test dispute"},
    )
    dispute_id = dispute_response.json()["id"]
    await client.post(
        f"/api/v1/disputes/{dispute_id}/resolve",
        headers=_headers(admin_token),
        json={"resolution": "release_to_payee"},
    )

    response = await client.get(
        "/api/v1/reports/operator-activity",
        headers=_headers(admin_token),
        params={"format": "csv"},
    )
    reader = csv.DictReader(io.StringIO(response.text))
    actions = [row["action"] for row in reader]
    assert "dispute.resolved" in actions


# ---------------------------------------------------- financial summary


async def test_financial_summary_requires_admin(client: AsyncClient) -> None:
    token = (await _register(client, "rpt-regular3@example.com"))["token"]
    response = await client.get("/api/v1/reports/financial-summary", headers=_headers(token))
    assert response.status_code == 403


async def test_financial_summary_is_a_pdf(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    admin_token = await _make_admin_and_login(client, db_session, "rpt-admin5@example.com")

    response = await client.get(
        "/api/v1/reports/financial-summary", headers=_headers(admin_token)
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/pdf"
    assert _is_pdf(response.content)


# ---------------------------------------------------- additional coverage


async def test_escrow_history_report_for_a_cancelled_escrow(client: AsyncClient) -> None:
    payer = await _register(client, "rpt-cancel-payer@example.com", "Payer")
    await _register(client, "rpt-cancel-payee@example.com", "Payee")

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "rpt-cancel-payee@example.com",
            "amount": "60.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/cancel", headers=_headers(payer["token"]), json={}
    )

    response = await client.get(
        f"/api/v1/reports/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert response.status_code == 200
    assert _is_pdf(response.content)


async def test_escrow_history_report_for_a_refunded_escrow(client: AsyncClient) -> None:
    payer = await _register(client, "rpt-refund-payer@example.com", "Payer")
    payee = await _register(client, "rpt-refund-payee@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "200.00"}
    )

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "rpt-refund-payee@example.com",
            "amount": "80.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    # Refund requires the payee's agreement, not the payer's — see
    # EscrowTransactionEngine's module docstring for why.
    refund_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/refund",
        headers=_headers(payee["token"]),
        json={},
    )
    assert refund_response.status_code == 200
    assert refund_response.json()["refunded_at"] is not None

    response = await client.get(
        f"/api/v1/reports/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert response.status_code == 200
    assert _is_pdf(response.content)


async def test_escrow_history_report_includes_dispute_section(client: AsyncClient) -> None:
    payer = await _register(client, "rpt-disp-payer@example.com", "Payer")
    await _register(client, "rpt-disp-payee@example.com", "Payee")
    await client.post(
        "/api/v1/wallet/deposit", headers=_headers(payer["token"]), json={"amount": "300.00"}
    )

    create_response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "rpt-disp-payee@example.com",
            "amount": "90.00",
            "description": "x",
        },
    )
    escrow_id = create_response.json()["id"]
    await client.post(
        f"/api/v1/escrows/{escrow_id}/fund", headers=_headers(payer["token"]), json={}
    )
    await client.post(
        f"/api/v1/escrows/{escrow_id}/dispute",
        headers=_headers(payer["token"]),
        json={"reason": "test dispute for report"},
    )

    response = await client.get(
        f"/api/v1/reports/escrows/{escrow_id}", headers=_headers(payer["token"])
    )
    assert response.status_code == 200
    assert _is_pdf(response.content)
    # A report with a dispute section should be larger than one without.
    assert len(response.content) > 2500


async def test_wallet_statement_pdf_with_no_transactions(client: AsyncClient) -> None:
    payer = await _register(client, "rpt-empty-wallet@example.com", "Payer")

    response = await client.get(
        "/api/v1/reports/wallet/statement", headers=_headers(payer["token"])
    )
    assert response.status_code == 200
    assert _is_pdf(response.content)


async def test_audit_export_pdf_with_no_entries_in_range(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    admin_token = await _make_admin_and_login(client, db_session, "rpt-admin7@example.com")

    future_start = (datetime.now(UTC) + timedelta(days=365)).isoformat()
    response = await client.get(
        "/api/v1/reports/audit",
        headers=_headers(admin_token),
        params={"format": "pdf", "start_date": future_start},
    )
    assert response.status_code == 200
    assert _is_pdf(response.content)


async def test_financial_summary_pdf_with_escrow_data(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    payer = await _register(client, "rpt-fs-payer@example.com", "Payer")
    await _register(client, "rpt-fs-payee@example.com", "Payee")
    await client.post(
        "/api/v1/escrows",
        headers=_headers(payer["token"]),
        json={
            "payee_email": "rpt-fs-payee@example.com",
            "amount": "45.00",
            "description": "x",
        },
    )
    admin_token = await _make_admin_and_login(client, db_session, "rpt-admin6@example.com")

    response = await client.get(
        "/api/v1/reports/financial-summary", headers=_headers(admin_token)
    )
    assert response.status_code == 200
    assert _is_pdf(response.content)
    assert len(response.content) > 1500
