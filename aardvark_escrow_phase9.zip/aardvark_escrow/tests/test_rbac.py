"""Unit tests for require_role.

No endpoint consumes it yet (that lands with the admin-only dispute
resolution endpoint in Phase 7), but the RBAC mechanism itself should
already be correct and tested. `require_role`'s inner check function
takes `current_user` via `Depends(get_current_user)` for FastAPI's
benefit, but it's a plain async function underneath, so it's called
directly here with a hand-built User instead of going through FastAPI's
dependency resolution.
"""
import pytest

from app.core.exceptions import AuthorizationError
from app.domain.entities.enums import UserRole
from app.domain.entities.user import User
from app.security.dependencies import require_role


def _make_user(role: UserRole) -> User:
    return User(email="x@example.com", hashed_password="x", full_name="X", role=role)


async def test_require_role_allows_user_with_permitted_role() -> None:
    check = require_role(UserRole.ADMIN, UserRole.USER)
    admin = _make_user(UserRole.ADMIN)
    returned = await check(current_user=admin)
    assert returned is admin


async def test_require_role_rejects_user_without_permitted_role() -> None:
    check = require_role(UserRole.ADMIN)
    regular_user = _make_user(UserRole.USER)
    with pytest.raises(AuthorizationError):
        await check(current_user=regular_user)
