"""Wallet request/response schemas."""
from datetime import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, Field

from app.schemas.base import ORMModel


class WalletPublic(ORMModel):
    id: UUID
    currency: str
    balance: Decimal
    held_balance: Decimal
    # Wallet.available_balance is a @property, not a column — ORMModel's
    # from_attributes reads it the same as any other attribute.
    available_balance: Decimal
    created_at: datetime


class DepositRequest(BaseModel):
    amount: Decimal = Field(gt=0, max_digits=18, decimal_places=2)
    description: str = Field(default="Wallet deposit", max_length=500)
    idempotency_key: str | None = Field(default=None, max_length=255)


class WithdrawRequest(BaseModel):
    amount: Decimal = Field(gt=0, max_digits=18, decimal_places=2)
    description: str = Field(default="Wallet withdrawal", max_length=500)
    idempotency_key: str | None = Field(default=None, max_length=255)
