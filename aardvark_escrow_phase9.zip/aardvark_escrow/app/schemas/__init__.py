"""Pydantic request/response schemas.

Kept separate from `app.domain.entities` deliberately — API contracts and
persistence models are allowed to diverge, and this package is where that
boundary is enforced. `base.ORMModel` is the shared config for response
schemas built from ORM entities; `validators.py` holds field validators
shared across more than one schema (e.g. password strength, checked by
both `auth.RegisterRequest` and `user.UpdateUserRequest`).
"""
