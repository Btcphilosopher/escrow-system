"""Escrow request/response schemas."""
from datetime import UTC, datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, field_validator

from app.domain.entities.enums import EscrowStatus
from app.schemas.base import ORMModel


class CreateEscrowRequest(BaseModel):
    payee_email: EmailStr
    amount: Decimal = Field(gt=0, max_digits=18, decimal_places=2)
    currency: str = Field(default="GBP", min_length=3, max_length=3)
    description: str = Field(min_length=1, max_length=2000)
    terms: str | None = Field(default=None, max_length=5000)
    external_reference: str | None = Field(default=None, max_length=255)
    expires_at: datetime | None = Field(
        default=None,
        description=(
            "Optional funding deadline. If still unfunded past this time, "
            "the escrow is automatically cancelled by a background worker "
            "(Phase 8) — see app.workers.tasks.escrow_expiry."
        ),
    )

    @field_validator("expires_at")
    @classmethod
    def _expires_at_must_be_in_the_future(cls, value: datetime | None) -> datetime | None:
        if value is not None and value <= datetime.now(UTC):
            raise ValueError("expires_at must be in the future")
        return value


class CancelEscrowRequest(BaseModel):
    reason: str | None = Field(default=None, max_length=1000)


class FundEscrowRequest(BaseModel):
    idempotency_key: str | None = Field(default=None, max_length=255)


class ReleaseEscrowRequest(BaseModel):
    idempotency_key: str | None = Field(default=None, max_length=255)


class RefundEscrowRequest(BaseModel):
    reason: str | None = Field(default=None, max_length=1000)
    idempotency_key: str | None = Field(default=None, max_length=255)


class EscrowPublic(ORMModel):
    id: UUID
    payer_id: UUID
    payee_id: UUID
    status: EscrowStatus
    amount: Decimal
    fee_amount: Decimal
    currency: str
    description: str
    terms: str | None
    external_reference: str | None
    funded_at: datetime | None
    released_at: datetime | None
    refunded_at: datetime | None
    cancelled_at: datetime | None
    expires_at: datetime | None
    created_at: datetime
    updated_at: datetime
