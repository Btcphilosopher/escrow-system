"""Report endpoints — all return a file (PDF or CSV), not JSON.

Kept as a dedicated `/reports` namespace rather than scattered across
`escrows.py`/`wallet.py`/`audit.py`: every route here returns a download,
which is a different contract from the JSON list/detail endpoints those
files already expose, and grouping them makes the "give me a document"
surface of the API easy to find in one place. The underlying data
gathering still reuses those other modules' services directly — see
`app.audit.service.ReportService`.
"""
from datetime import datetime
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import ReportService
from app.database.session import get_db
from app.domain.entities.enums import UserRole
from app.domain.entities.user import User
from app.security.dependencies import get_current_user, require_role

router = APIRouter(prefix="/reports", tags=["reports"])

ReportFormat = Literal["pdf", "csv"]

_MEDIA_TYPES = {
    "pdf": "application/pdf",
    "csv": "text/csv",
}


def _file_response(content: bytes, *, format: ReportFormat, filename: str) -> Response:
    return Response(
        content=content,
        media_type=_MEDIA_TYPES[format],
        headers={"Content-Disposition": f'attachment; filename="{filename}.{format}"'},
    )


@router.get("/escrows/{escrow_id}")
async def escrow_history_report(
    escrow_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> Response:
    content = await ReportService(db).escrow_history_pdf(escrow_id, user_id=current_user.id)
    return _file_response(content, format="pdf", filename=f"escrow-{escrow_id}-history")


@router.get("/wallet/statement")
async def wallet_statement_report(
    format: ReportFormat = Query(default="pdf"),
    start_date: datetime | None = Query(default=None),
    end_date: datetime | None = Query(default=None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> Response:
    content = await ReportService(db).wallet_statement(
        current_user.id, format=format, start=start_date, end=end_date
    )
    return _file_response(content, format=format, filename="wallet-statement")


@router.get("/audit")
async def audit_export_report(
    format: ReportFormat = Query(default="csv"),
    start_date: datetime | None = Query(default=None),
    end_date: datetime | None = Query(default=None),
    limit: int = Query(default=1000, ge=1, le=10000),
    _admin: User = Depends(require_role(UserRole.ADMIN)),
    db: AsyncSession = Depends(get_db),
) -> Response:
    content = await ReportService(db).audit_export(
        format=format, start=start_date, end=end_date, limit=limit
    )
    return _file_response(content, format=format, filename="audit-export")


@router.get("/operator-activity")
async def operator_activity_report(
    format: ReportFormat = Query(default="csv"),
    start_date: datetime | None = Query(default=None),
    end_date: datetime | None = Query(default=None),
    limit: int = Query(default=1000, ge=1, le=10000),
    _admin: User = Depends(require_role(UserRole.ADMIN)),
    db: AsyncSession = Depends(get_db),
) -> Response:
    content = await ReportService(db).operator_activity(
        format=format, start=start_date, end=end_date, limit=limit
    )
    return _file_response(content, format=format, filename="operator-activity")


@router.get("/financial-summary")
async def financial_summary_report(
    _admin: User = Depends(require_role(UserRole.ADMIN)),
    db: AsyncSession = Depends(get_db),
) -> Response:
    content = await ReportService(db).financial_summary_pdf()
    return _file_response(content, format="pdf", filename="financial-summary")
