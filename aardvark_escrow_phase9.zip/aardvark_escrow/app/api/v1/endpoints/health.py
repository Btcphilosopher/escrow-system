"""Health, readiness, and liveness probes.

Kept separate from the domain API surface deliberately — these are
infrastructure endpoints consumed by orchestrators (Kubernetes, load
balancers), not by API clients, and carry no auth requirement.
"""
from fastapi import APIRouter, Depends, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db

router = APIRouter(tags=["health"])


@router.get("/health", status_code=status.HTTP_200_OK)
async def health() -> dict[str, str]:
    """Basic liveness check — does the process respond at all."""
    return {"status": "ok"}


@router.get("/health/live", status_code=status.HTTP_200_OK)
async def liveness() -> dict[str, str]:
    """Kubernetes liveness probe."""
    return {"status": "alive"}


@router.get("/health/ready", status_code=status.HTTP_200_OK)
async def readiness(db: AsyncSession = Depends(get_db)) -> dict[str, str]:
    """Kubernetes readiness probe — verifies the database is reachable."""
    await db.execute(text("SELECT 1"))
    return {"status": "ready"}
