"""Dispute service.

Handles the three dispute endpoints: raising a dispute, submitting
evidence, and an admin resolving it. Resolution triggers actual money
movement by delegating to `EscrowTransactionEngine` (Phase 6):
RELEASE_TO_PAYEE and REFUND_TO_PAYER reuse its existing admin-authorized
DISPUTED-starting-state paths directly; SPLIT uses the dedicated
`EscrowTransactionEngine.split` method (Phase 7).

**Deliberate two-transaction trade-off in `resolve_dispute`.** The money
movement and the `Dispute` row's own status update are two separate
commits, not one atomic transaction. This is a conscious choice, not an
oversight: `EscrowTransactionEngine`'s methods are already self-contained,
atomic, and idempotency-safe on their own (Phase 6). Threading an
externally-owned `UnitOfWork` through that already-shipped, already-tested
code — so a caller could fold its own writes into the same commit — would
add real complexity for a risk that's small in practice: the `Dispute`
update that follows is a handful of scalar column assignments with no
numeric constraints or lock contention, overwhelmingly unlikely to fail
right after a successful money movement. And if it ever did fail, it's
safely retryable: the escrow's own terminal status (already committed)
naturally prevents re-running the financial half, since
`EscrowStateMachine` would reject re-transitioning an already-terminal
escrow with `InvalidStateTransitionError`.
"""
from datetime import UTC, datetime
from decimal import Decimal
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import AuthorizationError, DomainError, NotFoundError
from app.database.unit_of_work import UnitOfWork
from app.domain.entities.audit import AuditAction, AuditLog
from app.domain.entities.dispute import Dispute, Evidence
from app.domain.entities.enums import (
    DisputeResolution,
    DisputeStatus,
    EscrowStatus,
    NotificationType,
    UserRole,
)
from app.domain.entities.escrow import Escrow
from app.domain.entities.user import User
from app.domain.services.escrow_state_machine import EscrowStateMachine
from app.domain.services.escrow_transaction_engine import EscrowTransactionEngine
from app.domain.services.notification_helpers import notify


class DisputeService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def raise_dispute(
        self, escrow_id: UUID, *, current_user: User, reason: str
    ) -> Dispute:
        async with UnitOfWork(self._session) as uow:
            escrow = await uow.escrows.get_for_update(escrow_id)
            if escrow is None or current_user.id not in (escrow.payer_id, escrow.payee_id):
                raise NotFoundError("Escrow not found")

            event = EscrowStateMachine.transition(
                escrow, EscrowStatus.DISPUTED, actor_id=current_user.id, reason=reason
            )
            uow.session.add(event)

            dispute = Dispute(
                escrow_id=escrow.id,
                raised_by_id=current_user.id,
                status=DisputeStatus.OPEN,
                reason=reason,
            )
            uow.disputes.add(dispute)
            await uow.session.flush()

            uow.audit_log.add(
                AuditLog(
                    actor_id=current_user.id,
                    action=AuditAction.DISPUTE_OPENED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                )
            )

            other_party_id = (
                escrow.payee_id if current_user.id == escrow.payer_id else escrow.payer_id
            )
            notify(
                uow,
                other_party_id,
                NotificationType.DISPUTE_OPENED,
                title="Dispute opened",
                message=f"A dispute was opened on: {escrow.description}",
                reference_type="dispute",
                reference_id=dispute.id,
            )

            await uow.commit()
            return dispute

    async def submit_evidence(
        self,
        dispute_id: UUID,
        *,
        current_user: User,
        description: str,
        file_url: str | None = None,
        file_hash: str | None = None,
    ) -> Evidence:
        async with UnitOfWork(self._session) as uow:
            dispute = await uow.disputes.get_by_id(dispute_id)
            if dispute is None:
                raise NotFoundError("Dispute not found")

            escrow = await uow.escrows.get_by_id(dispute.escrow_id)
            if escrow is None or current_user.id not in (escrow.payer_id, escrow.payee_id):
                raise NotFoundError("Dispute not found")

            if dispute.status not in (DisputeStatus.OPEN, DisputeStatus.UNDER_REVIEW):
                raise DomainError("Evidence can only be submitted while a dispute is open")

            evidence = Evidence(
                dispute_id=dispute.id,
                submitted_by_id=current_user.id,
                description=description,
                file_url=file_url,
                file_hash=file_hash,
            )
            uow.session.add(evidence)
            await uow.session.flush()

            uow.audit_log.add(
                AuditLog(
                    actor_id=current_user.id,
                    action=AuditAction.DISPUTE_EVIDENCE_SUBMITTED,
                    resource_type="dispute",
                    resource_id=dispute.id,
                )
            )
            await uow.commit()
            return evidence

    async def resolve_dispute(
        self,
        dispute_id: UUID,
        *,
        current_user: User,
        resolution: DisputeResolution,
        resolution_notes: str | None = None,
        release_amount: Decimal | None = None,
    ) -> Dispute:
        if current_user.role != UserRole.ADMIN:
            raise AuthorizationError("Only an admin can resolve a dispute")

        async with UnitOfWork(self._session) as uow:
            dispute = await uow.disputes.get_by_id(dispute_id)
            if dispute is None:
                raise NotFoundError("Dispute not found")
            if dispute.status not in (DisputeStatus.OPEN, DisputeStatus.UNDER_REVIEW):
                raise DomainError("This dispute has already been resolved")
            escrow_id = dispute.escrow_id

        escrow = await self._get_escrow_parties(escrow_id)

        # Money movement: its own, fully self-contained transaction — see
        # this module's docstring for why it isn't combined with the
        # Dispute row update below into one commit.
        engine = EscrowTransactionEngine(self._session)
        if resolution == DisputeResolution.RELEASE_TO_PAYEE:
            await engine.release(escrow_id, current_user=current_user)
        elif resolution == DisputeResolution.REFUND_TO_PAYER:
            await engine.refund(escrow_id, current_user=current_user, reason=resolution_notes)
        elif resolution == DisputeResolution.SPLIT:
            if release_amount is None:
                raise DomainError("release_amount is required for a split resolution")
            await engine.split(
                escrow_id, current_user=current_user, release_amount=release_amount
            )

        async with UnitOfWork(self._session) as uow:
            resolved_dispute = await uow.disputes.get_by_id(dispute_id)
            if resolved_dispute is None:
                raise NotFoundError("Dispute not found")  # pragma: no cover - defensive

            resolved_dispute.status = DisputeStatus.RESOLVED
            resolved_dispute.resolution = resolution
            resolved_dispute.resolution_notes = resolution_notes
            resolved_dispute.resolved_by_id = current_user.id
            resolved_dispute.resolved_at = datetime.now(UTC)

            uow.audit_log.add(
                AuditLog(
                    actor_id=current_user.id,
                    action=AuditAction.DISPUTE_RESOLVED,
                    resource_type="dispute",
                    resource_id=resolved_dispute.id,
                )
            )

            for party_id in (escrow.payer_id, escrow.payee_id):
                notify(
                    uow,
                    party_id,
                    NotificationType.DISPUTE_RESOLVED,
                    title="Dispute resolved",
                    message=(
                        f"The dispute on '{escrow.description}' was resolved: "
                        f"{resolution.value}"
                    ),
                    reference_type="dispute",
                    reference_id=resolved_dispute.id,
                )

            await uow.commit()
            return resolved_dispute

    async def _get_escrow_parties(self, escrow_id: UUID) -> Escrow:
        async with UnitOfWork(self._session) as uow:
            escrow = await uow.escrows.get_by_id(escrow_id)
            if escrow is None:
                raise NotFoundError("Escrow not found")  # pragma: no cover - defensive
            return escrow
