"""Wallet service.

Wallets are provisioned lazily: a user has no `Wallet` row until the
first time one of these endpoints needs it (`GET /wallet`,
`POST /wallet/deposit`, `POST /wallet/withdraw` all call
`get_or_create_wallet`). Deposit and withdraw both take a `SELECT ... FOR
UPDATE` row lock before mutating the balance, so two concurrent requests
against the same wallet serialise instead of racing.

Deposits credit the wallet directly on request. There's no payment
gateway anywhere in this stack (see requirements.txt) — in a real
deployment, this endpoint would sit behind a verified payment provider
webhook rather than being callable by any authenticated user for any
amount. What's built here is the ledger and locking discipline that
webhook handler would need, not payment collection itself; the spec's
endpoint list calls for `POST /wallet/deposit` as a direct call, so
that's what's implemented, with this caveat on the record.

Idempotency is enforced by the unique constraint already on
`WalletTransaction.idempotency_key` (Phase 2): a replayed request with
the same key hits a database conflict, which this service catches and
turns into "return the original result" rather than an error. Phase 6
generalizes this into a proper reusable mechanism (a Redis-backed
pre-check that avoids even re-running side effects, not just catching
the conflict after the fact) for the escrow transaction engine.
"""
from decimal import Decimal
from uuid import UUID

from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ConflictError, DomainError, InsufficientFundsError, NotFoundError
from app.database.unit_of_work import UnitOfWork
from app.domain.entities.audit import AuditAction, AuditLog
from app.domain.entities.enums import WalletTransactionType
from app.domain.entities.wallet import Wallet, WalletTransaction


class WalletService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_or_create_wallet(self, user_id: UUID) -> Wallet:
        existing = await self._get_existing_wallet(user_id)
        if existing is not None:
            return existing

        async with UnitOfWork(self._session) as uow:
            wallet = Wallet(user_id=user_id)
            uow.wallets.add(wallet)
            try:
                await uow.commit()
            except IntegrityError:
                # Lost a race with a concurrent request creating this
                # user's wallet (unique constraint on wallet.user_id) —
                # the other request won, so just fetch what it created.
                await uow.rollback()
                won_by_other_request = await uow.wallets.get_by_user_id(user_id)
                if won_by_other_request is None:
                    raise  # pragma: no cover - shouldn't happen; re-raise if it does
                return won_by_other_request
            return wallet

    async def deposit(
        self,
        user_id: UUID,
        *,
        amount: Decimal,
        description: str,
        idempotency_key: str | None = None,
    ) -> Wallet:
        if amount <= 0:
            raise DomainError("Deposit amount must be positive")

        wallet = await self.get_or_create_wallet(user_id)

        async with UnitOfWork(self._session) as uow:
            locked_wallet = await uow.wallets.get_for_update(wallet.id)
            if locked_wallet is None:
                raise NotFoundError("Wallet not found")  # pragma: no cover - defensive

            locked_wallet.balance += amount
            uow.session.add(
                WalletTransaction(
                    wallet_id=locked_wallet.id,
                    type=WalletTransactionType.DEPOSIT,
                    amount=amount,
                    balance_after=locked_wallet.balance,
                    description=description,
                    idempotency_key=idempotency_key,
                )
            )
            uow.audit_log.add(
                AuditLog(
                    actor_id=user_id,
                    action=AuditAction.WALLET_DEPOSITED,
                    resource_type="wallet",
                    resource_id=locked_wallet.id,
                )
            )

            try:
                await uow.commit()
            except IntegrityError as exc:
                return await self._handle_replayed_request(uow, idempotency_key, exc)

            return locked_wallet

    async def withdraw(
        self,
        user_id: UUID,
        *,
        amount: Decimal,
        description: str,
        idempotency_key: str | None = None,
    ) -> Wallet:
        if amount <= 0:
            raise DomainError("Withdrawal amount must be positive")

        wallet = await self.get_or_create_wallet(user_id)

        async with UnitOfWork(self._session) as uow:
            locked_wallet = await uow.wallets.get_for_update(wallet.id)
            if locked_wallet is None:
                raise NotFoundError("Wallet not found")  # pragma: no cover - defensive

            if locked_wallet.available_balance < amount:
                raise InsufficientFundsError(
                    f"Insufficient available balance: have "
                    f"{locked_wallet.available_balance}, requested {amount}"
                )

            locked_wallet.balance -= amount
            uow.session.add(
                WalletTransaction(
                    wallet_id=locked_wallet.id,
                    type=WalletTransactionType.WITHDRAWAL,
                    amount=-amount,
                    balance_after=locked_wallet.balance,
                    description=description,
                    idempotency_key=idempotency_key,
                )
            )
            uow.audit_log.add(
                AuditLog(
                    actor_id=user_id,
                    action=AuditAction.WALLET_WITHDRAWN,
                    resource_type="wallet",
                    resource_id=locked_wallet.id,
                )
            )

            try:
                await uow.commit()
            except IntegrityError as exc:
                return await self._handle_replayed_request(uow, idempotency_key, exc)

            return locked_wallet

    async def _get_existing_wallet(self, user_id: UUID) -> Wallet | None:
        async with UnitOfWork(self._session) as uow:
            return await uow.wallets.get_by_user_id(user_id)

    async def _handle_replayed_request(
        self, uow: UnitOfWork, idempotency_key: str | None, exc: IntegrityError
    ) -> Wallet:
        """Turn a replayed deposit/withdraw into its original result.

        Called after `IntegrityError` from the unique constraint on
        `idempotency_key`. Re-fetches fresh rows rather than touching the
        transaction's now-expired objects — `session.rollback()` expires
        every object in the session, and an async session can't do the
        implicit re-load that touching an expired attribute would
        normally trigger.
        """
        await uow.rollback()

        if idempotency_key is not None:
            existing_txn = await uow.wallets.get_transaction_by_idempotency_key(
                idempotency_key
            )
            if existing_txn is not None:
                fresh_wallet = await uow.wallets.get_by_id(existing_txn.wallet_id)
                if fresh_wallet is not None:
                    return fresh_wallet

        raise ConflictError("This request has already been processed") from exc
