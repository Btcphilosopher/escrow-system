"""Dispute and Evidence entities.

A Dispute is raised against a FUNDED or IN_PROGRESS escrow and freezes it
(status moves to DISPUTED) until an admin resolves it. `Evidence` rows are
append-only submissions from either party — once submitted, evidence is
never edited, only superseded by further submissions, which is what makes
it usable as a record in a resolution decision.
"""
from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import DateTime, Enum, ForeignKey, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, CreatedAtMixin, TimestampMixin, UUIDPrimaryKeyMixin
from app.domain.entities.enums import DisputeResolution, DisputeStatus

if TYPE_CHECKING:
    from app.domain.entities.escrow import Escrow
    from app.domain.entities.user import User


class Dispute(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "disputes"
    __table_args__ = (
        Index("ix_disputes_escrow_id_status", "escrow_id", "status"),
    )

    escrow_id: Mapped[UUID] = mapped_column(
        ForeignKey("escrows.id", ondelete="RESTRICT"), nullable=False
    )
    raised_by_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )

    status: Mapped[DisputeStatus] = mapped_column(
        Enum(DisputeStatus, name="dispute_status"),
        nullable=False,
        default=DisputeStatus.OPEN,
    )
    reason: Mapped[str] = mapped_column(Text, nullable=False)

    resolution: Mapped[DisputeResolution | None] = mapped_column(
        Enum(DisputeResolution, name="dispute_resolution"), nullable=True
    )
    resolution_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    resolved_by_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    resolved_at: Mapped["datetime | None"] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    escrow: Mapped["Escrow"] = relationship(back_populates="disputes")
    raised_by: Mapped["User"] = relationship(foreign_keys=[raised_by_id])
    resolved_by: Mapped["User | None"] = relationship(foreign_keys=[resolved_by_id])
    evidence: Mapped[list["Evidence"]] = relationship(
        back_populates="dispute", order_by="Evidence.created_at"
    )

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return f"<Dispute id={self.id} escrow_id={self.escrow_id} status={self.status.value}>"


class Evidence(Base, UUIDPrimaryKeyMixin, CreatedAtMixin):
    """A single, immutable evidence submission attached to a dispute."""

    __tablename__ = "evidence"
    __table_args__ = (
        Index("ix_evidence_dispute_id_created_at", "dispute_id", "created_at"),
    )

    dispute_id: Mapped[UUID] = mapped_column(
        ForeignKey("disputes.id", ondelete="CASCADE"), nullable=False
    )
    submitted_by_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    description: Mapped[str] = mapped_column(Text, nullable=False)
    file_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    file_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)

    dispute: Mapped["Dispute"] = relationship(back_populates="evidence")
    submitted_by: Mapped["User"] = relationship(foreign_keys=[submitted_by_id])

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return f"<Evidence id={self.id} dispute_id={self.dispute_id}>"
