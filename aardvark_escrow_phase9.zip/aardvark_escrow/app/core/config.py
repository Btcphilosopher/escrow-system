"""Application configuration.

Centralised, environment-driven settings using Pydantic Settings.
All configuration must flow through this module — no `os.environ` access
elsewhere in the codebase. This keeps configuration auditable and makes it
trivial to see every tunable the platform exposes in one place.
"""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    ENVIRONMENT: str = "development"
    PROJECT_NAME: str = "Aardvark Escrow"
    API_V1_PREFIX: str = "/api/v1"

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://aardvark:aardvark@localhost:5432/aardvark_escrow"
    DATABASE_URL_SYNC: str = "postgresql+psycopg2://aardvark:aardvark@localhost:5432/aardvark_escrow"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20

    # Redis / Celery
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    # Auth
    JWT_SECRET_KEY: str = "change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # CORS
    CORS_ORIGINS: list[str] = ["http://localhost:3000"]

    # Rate limiting
    RATE_LIMIT_PER_MINUTE: int = 60

    # Idempotency
    IDEMPOTENCY_KEY_TTL_SECONDS: int = 86400

    LOG_LEVEL: str = "INFO"

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"


@lru_cache
def get_settings() -> Settings:
    """Return a process-wide cached Settings instance.

    Using lru_cache rather than a bare module-level instance makes the
    settings easy to override in tests via `get_settings.cache_clear()`.
    """
    return Settings()


settings = get_settings()
