"""Declarative base and shared model mixins.

Phase 2 introduces the concrete domain models (User, Wallet, Escrow,
EscrowTransaction, EscrowEvent, Dispute, Evidence, Notification, AuditLog,
APIKey, RefreshToken). This module only defines the base class and the
mixins every one of those models will share, so they have a single,
consistent foundation from day one:

- UUID primary keys (never auto-increment integers — avoids leaking
  sequence/volume information across a public API).
- created_at / updated_at timestamps, set at the database level so they're
  correct even for rows written outside the ORM (e.g. by a migration).
"""
import uuid
from datetime import datetime

from sqlalchemy import DateTime, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """Shared declarative base for all ORM models."""


class UUIDPrimaryKeyMixin:
    """Gives a model a UUID primary key generated client-side."""

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )


class TimestampMixin:
    """Gives a model server-managed created_at / updated_at columns.

    Use this for mutable entities. For append-only/immutable tables
    (ledgers, audit logs, event streams) use `CreatedAtMixin` instead —
    the absence of `updated_at` is a deliberate signal that rows are
    never modified after insert.

    `eager_defaults=True` matters here, not just as tuning: without it,
    `updated_at` (an `onupdate=func.now()` column) is left *expired*
    after any UPDATE within the same session — e.g. a state-machine
    transition that flushes a status change after the initial INSERT
    already happened. Touching `.updated_at` afterwards (a Pydantic
    response schema serializing the entity, say) would then trigger an
    implicit lazy-reload, which fails outside an explicit `await` on an
    async session (`MissingGreenlet`). This setting makes SQLAlchemy
    fetch the fresh value via `RETURNING` as part of the same flush
    instead, so the attribute is always already populated.
    """

    __mapper_args__ = {"eager_defaults": True}

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class CreatedAtMixin:
    """Gives a model a single server-managed created_at column.

    Used for append-only tables — WalletTransaction, EscrowEvent,
    AuditLog, Evidence — where an `updated_at` column would wrongly imply
    rows can be edited in place. `eager_defaults=True` is set for the same
    reason as `TimestampMixin`, in case a row here is ever re-flushed for
    another reason within the same session.
    """

    __mapper_args__ = {"eager_defaults": True}

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
