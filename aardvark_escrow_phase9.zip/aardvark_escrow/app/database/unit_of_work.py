"""Unit of Work.

Coordinates one or more repositories against a single database
transaction, so a use case either commits everything it touched or rolls
back everything — never a partial write. Introduced now, in Phase 4,
ahead of the Phase 6 transaction engine that actually needs to touch two
genuinely independent aggregates (a wallet and an escrow) atomically, so
that engine gets to reuse this rather than invent transaction handling
from scratch under time pressure.

Usage:
    async with UnitOfWork(session) as uow:
        uow.wallets.add(wallet)
        ...
        await uow.commit()
    # Falling out of the `async with` block on an exception rolls back
    # automatically. Falling out normally without calling commit() does
    # NOT auto-commit — see the note in __aexit__ for why.
"""
from types import TracebackType
from typing import Self

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.repositories.api_key_repository import SQLAlchemyAPIKeyRepository
from app.domain.repositories.audit_log_repository import SQLAlchemyAuditLogRepository
from app.domain.repositories.dispute_repository import SQLAlchemyDisputeRepository
from app.domain.repositories.escrow_repository import SQLAlchemyEscrowRepository
from app.domain.repositories.notification_repository import SQLAlchemyNotificationRepository
from app.domain.repositories.refresh_token_repository import SQLAlchemyRefreshTokenRepository
from app.domain.repositories.user_repository import SQLAlchemyUserRepository
from app.domain.repositories.wallet_repository import SQLAlchemyWalletRepository


class UnitOfWork:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.users = SQLAlchemyUserRepository(session)
        self.wallets = SQLAlchemyWalletRepository(session)
        self.escrows = SQLAlchemyEscrowRepository(session)
        self.disputes = SQLAlchemyDisputeRepository(session)
        self.notifications = SQLAlchemyNotificationRepository(session)
        self.audit_log = SQLAlchemyAuditLogRepository(session)
        self.refresh_tokens = SQLAlchemyRefreshTokenRepository(session)
        self.api_keys = SQLAlchemyAPIKeyRepository(session)

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        if exc_type is not None:
            await self.rollback()
        # Deliberately no commit-on-clean-exit. An implicit commit here
        # would silently persist a use case that decided partway through
        # not to write anything (e.g. "nothing actually changed, skip the
        # audit log") — the caller must call commit() explicitly.

    async def commit(self) -> None:
        await self.session.commit()

    async def rollback(self) -> None:
        await self.session.rollback()
