"""PDF report rendering, via ReportLab.

Each function takes plain data (entities or simple values the service
layer already fetched) and returns raw PDF bytes — no database access
happens in this module, keeping rendering fully decoupled from data
gathering (`app.audit.service.ReportService` does the gathering; these
functions never see a session).

Narrative, multi-section reports (escrow history, the platform financial
summary) are PDF-only — there's no single natural tabular shape to export
them as CSV. Reports that are fundamentally one table (wallet statements,
audit exports, operator activity) offer both PDF and CSV — see
`app.audit.csv_export` for the CSV side of those three.
"""
from datetime import datetime
from decimal import Decimal
from io import BytesIO
from typing import Any

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.domain.entities.audit import AuditLog
from app.domain.entities.dispute import Dispute
from app.domain.entities.escrow import Escrow
from app.domain.entities.wallet import WalletTransaction

_STYLES = getSampleStyleSheet()
_TABLE_HEADER_STYLE = TableStyle(
    [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2b2b2b")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f5f5")]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]
)


def _build_pdf(title: str, subtitle: str, flowables: list[Any]) -> bytes:
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        title=title,
    )
    story: list[Any] = [
        Paragraph(title, _STYLES["Title"]),
        Paragraph(subtitle, _STYLES["Normal"]),
        Spacer(1, 0.5 * cm),
        *flowables,
    ]
    doc.build(story)
    return buffer.getvalue()


def render_escrow_history_pdf(escrow: Escrow, disputes: list[Dispute]) -> bytes:
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M UTC")
    flowables: list[Any] = []

    flowables.append(Paragraph("Escrow details", _STYLES["Heading2"]))
    detail_rows = [
        ["Escrow ID", str(escrow.id)],
        ["Status", escrow.status.value],
        ["Amount", f"{escrow.amount} {escrow.currency}"],
        ["Description", escrow.description],
        ["Payer ID", str(escrow.payer_id)],
        ["Payee ID", str(escrow.payee_id)],
        ["Created", escrow.created_at.strftime("%Y-%m-%d %H:%M UTC")],
    ]
    if escrow.funded_at:
        detail_rows.append(["Funded", escrow.funded_at.strftime("%Y-%m-%d %H:%M UTC")])
    if escrow.released_at:
        detail_rows.append(["Released", escrow.released_at.strftime("%Y-%m-%d %H:%M UTC")])
    if escrow.refunded_at:
        detail_rows.append(["Refunded", escrow.refunded_at.strftime("%Y-%m-%d %H:%M UTC")])
    if escrow.cancelled_at:
        detail_rows.append(["Cancelled", escrow.cancelled_at.strftime("%Y-%m-%d %H:%M UTC")])

    detail_table = Table(detail_rows, colWidths=[4 * cm, 12 * cm])
    detail_table.setStyle(
        TableStyle(
            [
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        )
    )
    flowables.append(detail_table)
    flowables.append(Spacer(1, 0.75 * cm))

    flowables.append(Paragraph("Status timeline", _STYLES["Heading2"]))
    event_rows: list[list[str]] = [["From", "To", "Actor", "Reason", "When"]]
    for event in sorted(escrow.events, key=lambda e: e.created_at):
        event_rows.append(
            [
                event.from_status.value if event.from_status else "—",
                event.to_status.value,
                str(event.actor_id) if event.actor_id else "system",
                event.reason or "",
                event.created_at.strftime("%Y-%m-%d %H:%M"),
            ]
        )
    event_table = Table(event_rows, colWidths=[2.5 * cm, 2.5 * cm, 3.5 * cm, 4.5 * cm, 3 * cm])
    event_table.setStyle(_TABLE_HEADER_STYLE)
    flowables.append(event_table)
    flowables.append(Spacer(1, 0.75 * cm))

    flowables.append(Paragraph("Transactions", _STYLES["Heading2"]))
    if escrow.transactions:
        txn_rows: list[list[str]] = [["Type", "Amount", "When"]]
        for txn in sorted(escrow.transactions, key=lambda t: t.created_at):
            txn_rows.append(
                [
                    txn.type.value,
                    f"{txn.amount} {escrow.currency}",
                    txn.created_at.strftime("%Y-%m-%d %H:%M"),
                ]
            )
        txn_table = Table(txn_rows, colWidths=[4 * cm, 5 * cm, 4 * cm])
        txn_table.setStyle(_TABLE_HEADER_STYLE)
        flowables.append(txn_table)
    else:
        flowables.append(Paragraph("No transactions recorded.", _STYLES["Normal"]))

    if disputes:
        flowables.append(Spacer(1, 0.75 * cm))
        flowables.append(Paragraph("Disputes", _STYLES["Heading2"]))
        dispute_rows: list[list[str]] = [["Status", "Reason", "Resolution", "Resolved"]]
        for dispute in disputes:
            dispute_rows.append(
                [
                    dispute.status.value,
                    dispute.reason,
                    dispute.resolution.value if dispute.resolution else "—",
                    dispute.resolved_at.strftime("%Y-%m-%d %H:%M")
                    if dispute.resolved_at
                    else "—",
                ]
            )
        dispute_table = Table(dispute_rows, colWidths=[2.5 * cm, 6 * cm, 3.5 * cm, 3 * cm])
        dispute_table.setStyle(_TABLE_HEADER_STYLE)
        flowables.append(dispute_table)

    return _build_pdf(
        "Escrow History Report",
        f"Generated {generated_at} — Escrow {escrow.id}",
        flowables,
    )


def render_wallet_statement_pdf(
    *,
    user_email: str,
    currency: str,
    balance: Decimal,
    held_balance: Decimal,
    transactions: list[WalletTransaction],
) -> bytes:
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M UTC")
    flowables: list[Any] = []

    summary_rows = [
        ["Account holder", user_email],
        ["Current balance", f"{balance} {currency}"],
        ["Held balance", f"{held_balance} {currency}"],
        ["Available balance", f"{balance - held_balance} {currency}"],
    ]
    summary_table = Table(summary_rows, colWidths=[5 * cm, 11 * cm])
    summary_table.setStyle(
        TableStyle(
            [
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
            ]
        )
    )
    flowables.append(summary_table)
    flowables.append(Spacer(1, 0.75 * cm))

    flowables.append(Paragraph("Transactions", _STYLES["Heading2"]))
    if transactions:
        rows: list[list[str]] = [["Date", "Type", "Amount", "Balance after", "Description"]]
        for txn in transactions:
            rows.append(
                [
                    txn.created_at.strftime("%Y-%m-%d %H:%M"),
                    txn.type.value,
                    f"{txn.amount} {currency}",
                    f"{txn.balance_after} {currency}",
                    txn.description,
                ]
            )
        table = Table(rows, colWidths=[3 * cm, 3 * cm, 3 * cm, 3 * cm, 4 * cm])
        table.setStyle(_TABLE_HEADER_STYLE)
        flowables.append(table)
    else:
        flowables.append(Paragraph("No transactions in this period.", _STYLES["Normal"]))

    return _build_pdf("Wallet Statement", f"Generated {generated_at}", flowables)


def render_audit_log_pdf(title: str, entries: list[AuditLog]) -> bytes:
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M UTC")
    flowables: list[Any] = []

    if entries:
        rows: list[list[str]] = [["When", "Actor", "Action", "Resource"]]
        for entry in entries:
            resource = (
                f"{entry.resource_type}:{entry.resource_id}"
                if entry.resource_id
                else entry.resource_type
            )
            rows.append(
                [
                    entry.created_at.strftime("%Y-%m-%d %H:%M"),
                    str(entry.actor_id) if entry.actor_id else "system",
                    entry.action,
                    resource,
                ]
            )
        table = Table(rows, colWidths=[3 * cm, 4 * cm, 4.5 * cm, 4.5 * cm])
        table.setStyle(_TABLE_HEADER_STYLE)
        flowables.append(table)
    else:
        flowables.append(Paragraph("No entries in this period.", _STYLES["Normal"]))

    return _build_pdf(title, f"Generated {generated_at} — {len(entries)} entries", flowables)


def render_financial_summary_pdf(stats: dict[str, Any]) -> bytes:
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M UTC")
    flowables: list[Any] = []

    summary_rows = [
        ["Total users", str(stats["total_users"])],
        ["Total released volume", stats["total_released_volume"]],
        ["Total wallet balance (all users)", stats["total_wallet_balance"]],
    ]
    summary_table = Table(summary_rows, colWidths=[7 * cm, 9 * cm])
    summary_table.setStyle(
        TableStyle(
            [
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
            ]
        )
    )
    flowables.append(summary_table)
    flowables.append(Spacer(1, 0.75 * cm))

    flowables.append(Paragraph("Escrows by status", _STYLES["Heading2"]))
    status_counts = stats["escrow_counts_by_status"]
    if status_counts:
        rows: list[list[str]] = [["Status", "Count"]]
        for status, count in sorted(status_counts.items()):
            rows.append([status, str(count)])
        table = Table(rows, colWidths=[6 * cm, 4 * cm])
        table.setStyle(_TABLE_HEADER_STYLE)
        flowables.append(table)
    else:
        flowables.append(Paragraph("No escrows recorded yet.", _STYLES["Normal"]))

    return _build_pdf("Platform Financial Summary", f"Generated {generated_at}", flowables)
