"""Report generation service.

Gathers the data each report needs (via repositories, same as every
other service in this codebase) and hands it to `app.audit.pdf` or
`app.audit.csv_export` for rendering. Authorization for the escrow
history report is deliberately delegated to `EscrowService.get_escrow`
rather than reimplemented here — that method already encodes "payer,
payee, or 404" correctly (Phase 5), and reports should never grant wider
access to a resource than the resource's own read endpoint does.

Reports are generated synchronously, on request — not queued as
background jobs with a "check back later" polling flow. Every report
here operates on bounded, reasonably-sized data (one escrow, one
wallet's transactions, a date-bounded slice of the audit log), so
synchronous generation is the right level of complexity for what's
actually being asked. A genuinely unbounded, slow report (e.g. "every
audit entry the platform has ever recorded") would call for a real
async job + storage pipeline, but nothing in the spec calls for that,
and building one speculatively would be complexity without a concrete
need driving its design.
"""
from datetime import datetime
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.csv_export import render_audit_log_csv, render_wallet_statement_csv
from app.audit.pdf import (
    render_audit_log_pdf,
    render_escrow_history_pdf,
    render_financial_summary_pdf,
    render_wallet_statement_pdf,
)
from app.database.unit_of_work import UnitOfWork
from app.domain.services.escrow_service import EscrowService
from app.domain.services.wallet_service import WalletService
from app.workers.tasks.statistics import compute_platform_statistics


class ReportService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def escrow_history_pdf(self, escrow_id: UUID, *, user_id: UUID) -> bytes:
        # Reuses EscrowService's own authorization (payer/payee/404) —
        # see this module's docstring for why that's deliberate.
        escrow = await EscrowService(self._session).get_escrow(escrow_id, user_id=user_id)

        async with UnitOfWork(self._session) as uow:
            disputes = await uow.disputes.list_for_escrow(escrow_id)

        return render_escrow_history_pdf(escrow, disputes)

    async def wallet_statement(
        self,
        user_id: UUID,
        *,
        format: str,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> bytes:
        wallet = await WalletService(self._session).get_or_create_wallet(user_id)

        async with UnitOfWork(self._session) as uow:
            transactions = await uow.wallets.list_transactions(wallet.id, start=start, end=end)
            user = await uow.users.get_by_id(user_id)
            assert user is not None  # the caller is always an authenticated, existing user

        if format == "csv":
            return render_wallet_statement_csv(transactions, wallet.currency)

        return render_wallet_statement_pdf(
            user_email=user.email,
            currency=wallet.currency,
            balance=wallet.balance,
            held_balance=wallet.held_balance,
            transactions=transactions,
        )

    async def audit_export(
        self,
        *,
        format: str,
        start: datetime | None = None,
        end: datetime | None = None,
        limit: int = 1000,
    ) -> bytes:
        async with UnitOfWork(self._session) as uow:
            entries = await uow.audit_log.list_by_date_range(start=start, end=end, limit=limit)

        if format == "csv":
            return render_audit_log_csv(entries)
        return render_audit_log_pdf("Audit Export Report", entries)

    async def operator_activity(
        self,
        *,
        format: str,
        start: datetime | None = None,
        end: datetime | None = None,
        limit: int = 1000,
    ) -> bytes:
        async with UnitOfWork(self._session) as uow:
            entries = await uow.audit_log.list_admin_actions(start=start, end=end, limit=limit)

        if format == "csv":
            return render_audit_log_csv(entries)
        return render_audit_log_pdf("Operator Activity Report", entries)

    async def financial_summary_pdf(self) -> bytes:
        stats = await compute_platform_statistics(self._session)
        return render_financial_summary_pdf(stats)
