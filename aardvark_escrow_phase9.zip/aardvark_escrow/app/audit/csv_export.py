"""CSV report rendering, via the standard library `csv` module.

Same shape as `app.audit.pdf`: plain functions taking data the service
layer already fetched, returning bytes, no database access here.
"""
import csv
from io import StringIO

from app.domain.entities.audit import AuditLog
from app.domain.entities.wallet import WalletTransaction


def _rows_to_csv_bytes(header: list[str], rows: list[list[str]]) -> bytes:
    buffer = StringIO()
    writer = csv.writer(buffer)
    writer.writerow(header)
    writer.writerows(rows)
    return buffer.getvalue().encode("utf-8")


def render_wallet_statement_csv(transactions: list[WalletTransaction], currency: str) -> bytes:
    header = ["date", "type", "amount", "currency", "balance_after", "description"]
    rows = [
        [
            txn.created_at.isoformat(),
            txn.type.value,
            str(txn.amount),
            currency,
            str(txn.balance_after),
            txn.description,
        ]
        for txn in transactions
    ]
    return _rows_to_csv_bytes(header, rows)


def render_audit_log_csv(entries: list[AuditLog]) -> bytes:
    header = ["timestamp", "actor_id", "action", "resource_type", "resource_id", "ip_address"]
    rows = [
        [
            entry.created_at.isoformat(),
            str(entry.actor_id) if entry.actor_id else "",
            entry.action,
            entry.resource_type,
            str(entry.resource_id) if entry.resource_id else "",
            entry.ip_address or "",
        ]
        for entry in entries
    ]
    return _rows_to_csv_bytes(header, rows)
