"""Background workers.

`celery_app.py` configures the Celery application and its Beat schedule.
`tasks/` holds the individual task implementations (notification
delivery, expired-escrow detection, daily wallet reconciliation,
platform statistics — Phase 8). `email.py` is the pluggable email-sending
abstraction the notification-delivery task uses.
"""
