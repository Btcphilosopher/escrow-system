"""Platform statistics generation.

Computes basic aggregate platform metrics (`compute_platform_statistics`)
and logs them periodically via a Celery task. Deliberately lightweight:
no new table is introduced to persist historical stats snapshots — what
history to keep, at what granularity, queryable how, is a genuine
reporting/persistence design decision that belongs with Phase 9's
reporting work, not bolted on here. What's built now is the computation
itself and the periodic trigger, ready for Phase 9 to persist and expose.
"""
import asyncio
from typing import Any

import structlog
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import AsyncSessionLocal
from app.domain.entities.enums import EscrowStatus
from app.domain.entities.escrow import Escrow
from app.domain.entities.user import User
from app.domain.entities.wallet import Wallet
from app.workers.celery_app import celery_app

logger = structlog.get_logger(__name__)


async def compute_platform_statistics(session: AsyncSession) -> dict[str, Any]:
    total_users = (
        await session.execute(select(func.count()).select_from(User))
    ).scalar_one()

    status_rows = (
        await session.execute(select(Escrow.status, func.count()).group_by(Escrow.status))
    ).all()
    escrow_counts_by_status = {status.value: count for status, count in status_rows}

    total_released_volume = (
        await session.execute(
            select(func.coalesce(func.sum(Escrow.amount), 0)).where(
                Escrow.status == EscrowStatus.RELEASED
            )
        )
    ).scalar_one()

    total_wallet_balance = (
        await session.execute(select(func.coalesce(func.sum(Wallet.balance), 0)))
    ).scalar_one()

    return {
        "total_users": total_users,
        "escrow_counts_by_status": escrow_counts_by_status,
        "total_released_volume": str(total_released_volume),
        "total_wallet_balance": str(total_wallet_balance),
    }


async def _generate_platform_statistics() -> dict[str, Any]:
    async with AsyncSessionLocal() as session:
        stats = await compute_platform_statistics(session)
    logger.info("platform_statistics", **stats)
    return stats


@celery_app.task(name="statistics.generate_platform_statistics")
def generate_platform_statistics_task() -> dict[str, Any]:
    return asyncio.run(_generate_platform_statistics())
