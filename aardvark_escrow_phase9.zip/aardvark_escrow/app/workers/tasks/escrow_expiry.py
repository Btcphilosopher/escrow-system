"""Expired-escrow detection task.

Escrows can optionally carry an `expires_at` (Phase 2 column, wired into
`POST /escrows` in Phase 8 — see `CreateEscrowRequest`). This task finds
escrows past that deadline while still `CREATED` or `AWAITING_PAYMENT` —
i.e. nobody funded them in time — and cancels them automatically.

Deliberately scoped to pre-funding states only. Once money is actually
held (`FUNDED` onward), auto-resolving an expired deadline would mean
fabricating a financial policy decision (auto-release? auto-refund?)
that nothing in the spec calls for and that has real consequences for
whichever party loses out. `expires_at` on a funded escrow is left
informational for now — a human (an admin, via Phase 7's dispute
resolution) should be the one deciding what happens to funds already at
stake past a deadline, not an unattended cron job.
"""
import asyncio
from typing import Any

import structlog

from app.database.session import AsyncSessionLocal
from app.domain.services.escrow_service import EscrowService
from app.workers.celery_app import celery_app

logger = structlog.get_logger(__name__)


async def _detect_expired_escrows(limit: int = 100) -> dict[str, int]:
    expired_count = 0
    failed_count = 0

    async with AsyncSessionLocal() as session:
        service = EscrowService(session)
        expired_escrow_ids = await service.list_expired_unfunded_escrow_ids(limit=limit)

        for escrow_id in expired_escrow_ids:
            try:
                await service.expire_escrow(escrow_id)
                expired_count += 1
            except Exception:
                logger.exception("escrow_expiry_failed", escrow_id=str(escrow_id))
                failed_count += 1

    return {"expired": expired_count, "failed": failed_count}


@celery_app.task(name="escrows.detect_expired")
def detect_expired_escrows_task() -> dict[str, Any]:
    return asyncio.run(_detect_expired_escrows())
