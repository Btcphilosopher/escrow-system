"""Daily wallet reconciliation task.

Verifies two independent invariants for every wallet:

1. **Balance.** Summing `WalletTransaction.amount` for the types that
   actually move `balance` (DEPOSIT, WITHDRAWAL, ESCROW_RELEASE) must
   equal the wallet's current `balance`. ESCROW_HOLD/ESCROW_REFUND are
   deliberately excluded — they move `held_balance`, not `balance` (see
   `WalletTransactionType`'s docstring, corrected in this phase once this
   exact reconciliation needed it to be precise).
2. **Held balance.** Summing the `amount` of escrows currently in a
   funds-held state (FUNDED, IN_PROGRESS, AWAITING_APPROVAL, DISPUTED)
   where the wallet's owner is the payer must equal `held_balance`. This
   is checked against *live escrow state*, not the wallet ledger —
   deliberately. A payer-side ESCROW_RELEASE ledger entry conflates two
   things (a balance decrease and a held-balance decrease) into one
   signed `amount` column; the current schema can't cleanly separate them
   for a ledger-only reconstruction. Escrow status is an independent,
   unambiguous source of truth for "what should currently be held" that
   sidesteps the problem entirely, rather than working around a
   ledger-schema limitation with something fragile.

Mismatches are logged and written as an `AuditLog` entry — not raised as
exceptions. A reconciliation job's role is to surface problems for a
human to investigate, not to crash the worker or silently "fix" a
balance itself.
"""
import asyncio
from decimal import Decimal
from typing import Any

import structlog
from sqlalchemy import func, select

from app.database.session import AsyncSessionLocal
from app.domain.entities.audit import AuditAction, AuditLog
from app.domain.entities.enums import EscrowStatus, WalletTransactionType
from app.domain.entities.escrow import Escrow
from app.domain.entities.wallet import Wallet, WalletTransaction
from app.workers.celery_app import celery_app

logger = structlog.get_logger(__name__)

_BALANCE_AFFECTING_TYPES = (
    WalletTransactionType.DEPOSIT,
    WalletTransactionType.WITHDRAWAL,
    WalletTransactionType.ESCROW_RELEASE,
)
_HELD_STATUSES = (
    EscrowStatus.FUNDED,
    EscrowStatus.IN_PROGRESS,
    EscrowStatus.AWAITING_APPROVAL,
    EscrowStatus.DISPUTED,
)


async def _reconcile_wallets() -> dict[str, int]:
    checked = 0
    mismatches = 0

    async with AsyncSessionLocal() as session:
        wallets = (await session.execute(select(Wallet))).scalars().all()

        for wallet in wallets:
            checked += 1

            ledger_balance = Decimal(
                (
                    await session.execute(
                        select(func.coalesce(func.sum(WalletTransaction.amount), 0)).where(
                            WalletTransaction.wallet_id == wallet.id,
                            WalletTransaction.type.in_(_BALANCE_AFFECTING_TYPES),
                        )
                    )
                ).scalar_one()
            )

            expected_held = Decimal(
                (
                    await session.execute(
                        select(func.coalesce(func.sum(Escrow.amount), 0)).where(
                            Escrow.payer_id == wallet.user_id,
                            Escrow.status.in_(_HELD_STATUSES),
                        )
                    )
                ).scalar_one()
            )

            balance_ok = ledger_balance == wallet.balance
            held_ok = expected_held == wallet.held_balance

            if balance_ok and held_ok:
                continue

            mismatches += 1
            logger.warning(
                "wallet_reconciliation_mismatch",
                wallet_id=str(wallet.id),
                ledger_balance=str(ledger_balance),
                actual_balance=str(wallet.balance),
                expected_held=str(expected_held),
                actual_held=str(wallet.held_balance),
            )
            session.add(
                AuditLog(
                    actor_id=None,
                    action=AuditAction.WALLET_RECONCILIATION_MISMATCH,
                    resource_type="wallet",
                    resource_id=wallet.id,
                    extra_data={
                        "ledger_balance": str(ledger_balance),
                        "actual_balance": str(wallet.balance),
                        "expected_held": str(expected_held),
                        "actual_held": str(wallet.held_balance),
                    },
                )
            )

        await session.commit()

    return {"checked": checked, "mismatches": mismatches}


@celery_app.task(name="reconciliation.daily_wallet_reconciliation")
def daily_wallet_reconciliation_task() -> dict[str, Any]:
    return asyncio.run(_reconcile_wallets())
