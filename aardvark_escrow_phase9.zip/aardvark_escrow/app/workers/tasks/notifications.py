"""Notification delivery task.

Picks up PENDING `Notification` rows — created as a side effect of
domain services since Phase 7 (see
`app.domain.services.notification_helpers`) — and delivers them via
`EmailSender`, updating each row's status to SENT or FAILED. See
`app.workers.tasks`'s module docstring for the sync-task/async-impl split
this and every other task module here follows.
"""
import asyncio
from typing import Any

import structlog

from app.database.session import AsyncSessionLocal
from app.domain.entities.enums import NotificationStatus
from app.domain.repositories.notification_repository import SQLAlchemyNotificationRepository
from app.domain.repositories.user_repository import SQLAlchemyUserRepository
from app.workers.celery_app import celery_app
from app.workers.email import get_email_sender

logger = structlog.get_logger(__name__)


async def _deliver_pending_notifications(limit: int = 100) -> dict[str, int]:
    sent = 0
    failed = 0
    email_sender = get_email_sender()

    async with AsyncSessionLocal() as session:
        notifications_repo = SQLAlchemyNotificationRepository(session)
        users_repo = SQLAlchemyUserRepository(session)

        pending = await notifications_repo.list_pending(limit=limit)
        for notification in pending:
            user = await users_repo.get_by_id(notification.user_id)
            if user is None:
                # The user was deleted between the notification being
                # created and delivery running — nowhere to send it.
                notification.status = NotificationStatus.FAILED
                failed += 1
                continue

            try:
                email_sender.send(
                    to=user.email, subject=notification.title, body=notification.message
                )
            except Exception:
                logger.exception(
                    "notification_delivery_failed", notification_id=str(notification.id)
                )
                notification.status = NotificationStatus.FAILED
                failed += 1
            else:
                notification.status = NotificationStatus.SENT
                sent += 1

        await session.commit()

    return {"sent": sent, "failed": failed}


@celery_app.task(name="notifications.deliver_pending")
def deliver_pending_notifications_task() -> dict[str, Any]:
    return asyncio.run(_deliver_pending_notifications())
