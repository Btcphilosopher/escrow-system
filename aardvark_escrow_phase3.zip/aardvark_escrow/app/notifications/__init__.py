"""Notification delivery.

Phase 8 adds a NotificationService plus Celery tasks for email/webhook
delivery, backing the Notification entity and the GET /notifications
endpoint.
"""
