"""User-facing schemas.

`UserPublic` deliberately omits `hashed_password` — it's not that the
field is excluded at serialization time, it's that the schema never
declares the field in the first place, so there's no way for it to leak
through this response model regardless of what future fields get added
to the `User` entity.
"""
from datetime import datetime
from uuid import UUID

from app.domain.entities.enums import UserRole, UserStatus
from app.schemas.base import ORMModel


class UserPublic(ORMModel):
    id: UUID
    email: str
    full_name: str
    role: UserRole
    status: UserStatus
    is_verified: bool
    created_at: datetime
