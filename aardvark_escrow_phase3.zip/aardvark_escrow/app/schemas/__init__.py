"""Pydantic request/response schemas.

Kept separate from `app.domain.entities` deliberately — API contracts and
persistence models are allowed to diverge, and this package is where that
boundary is enforced. `base.ORMModel` is the shared config for response
schemas built from ORM entities; `auth.py` and `user.py` hold the first
concrete schemas.
"""
