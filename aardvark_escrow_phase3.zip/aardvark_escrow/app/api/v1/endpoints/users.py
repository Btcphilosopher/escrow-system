"""User-facing endpoints.

Only `GET /users/me` lands in this phase — it exists here mainly to prove
the auth dependency chain works end-to-end. `PATCH /users/me` and the
wallet endpoints follow in Phase 4.
"""
from fastapi import APIRouter, Depends

from app.domain.entities.user import User
from app.schemas.user import UserPublic
from app.security.dependencies import get_current_user

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserPublic)
async def get_me(current_user: User = Depends(get_current_user)) -> UserPublic:
    return UserPublic.model_validate(current_user)
