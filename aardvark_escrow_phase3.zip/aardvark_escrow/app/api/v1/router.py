"""Aggregates all v1 API routers into a single mountable router.

Additional routers are wired in here as their phases land:
    Phase 4 — wallet (users.py gains PATCH /users/me)
    Phase 7 — escrows, disputes, audit, notifications
"""
from fastapi import APIRouter

from app.api.v1.endpoints import auth, health, users

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(users.router)
