"""Authentication service.

Orchestrates the register/login/refresh/logout use cases. Everything a
single call here does — user lookup, password check, refresh-token
issuance/revocation, and the accompanying audit log entry — happens
inside one database transaction via the `AsyncSession` this service is
constructed with, so e.g. a login can never record success in the audit
log while failing to persist the issued refresh token.

This service commits its own transaction rather than going through an
explicit Unit of Work: every operation here touches one coherent set of
related rows (a user, their refresh tokens, an audit entry) and never two
independent aggregates the way, say, releasing an escrow touches both a
wallet and an escrow. Phase 4 introduces a real `UnitOfWork` once
`WalletService` and `EscrowService` need to coordinate commits across
genuinely separate aggregates.
"""
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.exceptions import AuthenticationError, ConflictError
from app.domain.entities.audit import AuditAction, AuditLog
from app.domain.entities.enums import UserRole
from app.domain.entities.refresh_token import RefreshToken
from app.domain.entities.user import User
from app.domain.repositories.audit_log_repository import SQLAlchemyAuditLogRepository
from app.domain.repositories.refresh_token_repository import SQLAlchemyRefreshTokenRepository
from app.domain.repositories.user_repository import SQLAlchemyUserRepository
from app.security.jwt import create_access_token
from app.security.password import hash_password, verify_password
from app.security.refresh_tokens import generate_refresh_token, hash_refresh_token


@dataclass(frozen=True)
class AuthResult:
    user: User
    access_token: str
    refresh_token: str
    expires_in: int


class AuthService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._users = SQLAlchemyUserRepository(session)
        self._refresh_tokens = SQLAlchemyRefreshTokenRepository(session)
        self._audit_log = SQLAlchemyAuditLogRepository(session)

    async def register(
        self,
        *,
        email: str,
        password: str,
        full_name: str,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> AuthResult:
        email = email.strip().lower()
        if await self._users.get_by_email(email) is not None:
            raise ConflictError("An account with this email already exists")

        user = User(
            email=email,
            hashed_password=hash_password(password),
            full_name=full_name.strip(),
            role=UserRole.USER,
        )
        self._users.add(user)
        await self._session.flush()

        self._audit_log.add(
            AuditLog(
                actor_id=user.id,
                action=AuditAction.USER_REGISTERED,
                resource_type="user",
                resource_id=user.id,
                ip_address=ip_address,
                user_agent=user_agent,
            )
        )

        result = await self._issue_tokens(user, ip_address=ip_address, user_agent=user_agent)
        await self._session.commit()
        return result

    async def login(
        self,
        *,
        email: str,
        password: str,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> AuthResult:
        email = email.strip().lower()
        user = await self._users.get_by_email(email)

        if user is None or not verify_password(password, user.hashed_password):
            self._audit_log.add(
                AuditLog(
                    actor_id=user.id if user is not None else None,
                    action=AuditAction.USER_LOGIN_FAILED,
                    resource_type="user",
                    resource_id=user.id if user is not None else None,
                    ip_address=ip_address,
                    user_agent=user_agent,
                )
            )
            await self._session.commit()
            # Deliberately the same message whether the email doesn't
            # exist or the password is wrong — distinguishing the two
            # would let an attacker enumerate registered emails.
            raise AuthenticationError("Incorrect email or password")

        if not user.is_active:
            raise AuthenticationError("This account is not active")

        self._audit_log.add(
            AuditLog(
                actor_id=user.id,
                action=AuditAction.USER_LOGIN,
                resource_type="user",
                resource_id=user.id,
                ip_address=ip_address,
                user_agent=user_agent,
            )
        )
        result = await self._issue_tokens(user, ip_address=ip_address, user_agent=user_agent)
        await self._session.commit()
        return result

    async def refresh(
        self,
        *,
        raw_refresh_token: str,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> AuthResult:
        hashed = hash_refresh_token(raw_refresh_token)
        token_row = await self._refresh_tokens.get_by_hashed_token(hashed)

        if (
            token_row is None
            or token_row.is_revoked
            or token_row.expires_at < datetime.now(UTC)
        ):
            raise AuthenticationError("Invalid or expired refresh token")

        user = await self._users.get_by_id(token_row.user_id)
        if user is None or not user.is_active:
            raise AuthenticationError("Invalid or expired refresh token")

        # Rotate: revoke the presented token, issue a brand new pair. A
        # revoked token being presented again (token theft + reuse) is
        # rejected by the check above on the next attempt.
        token_row.revoked_at = datetime.now(UTC)

        result = await self._issue_tokens(user, ip_address=ip_address, user_agent=user_agent)
        await self._session.commit()
        return result

    async def logout(self, *, raw_refresh_token: str) -> None:
        hashed = hash_refresh_token(raw_refresh_token)
        token_row = await self._refresh_tokens.get_by_hashed_token(hashed)
        if token_row is None or token_row.is_revoked:
            return  # Logging out twice (or with a stale token) is not an error.

        token_row.revoked_at = datetime.now(UTC)
        self._audit_log.add(
            AuditLog(
                actor_id=token_row.user_id,
                action=AuditAction.USER_LOGOUT,
                resource_type="user",
                resource_id=token_row.user_id,
            )
        )
        await self._session.commit()

    async def _issue_tokens(
        self, user: User, *, ip_address: str | None, user_agent: str | None
    ) -> AuthResult:
        access_token = create_access_token(user.id, user.role)

        raw_refresh_token = generate_refresh_token()
        refresh_token_row = RefreshToken(
            user_id=user.id,
            hashed_token=hash_refresh_token(raw_refresh_token),
            expires_at=datetime.now(UTC) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
            ip_address=ip_address,
            user_agent=user_agent,
        )
        self._refresh_tokens.add(refresh_token_row)
        await self._session.flush()

        return AuthResult(
            user=user,
            access_token=access_token,
            refresh_token=raw_refresh_token,
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )
