"""Domain services.

Business logic that doesn't belong to a single entity lives here.
`AuthService` (Phase 3) orchestrates register/login/refresh/logout.
`WalletService` (Phase 4), `EscrowStateMachine` and
`EscrowTransactionEngine` (Phase 5/6) follow the same shape: they depend
only on repository interfaces, never on FastAPI or take a SQLAlchemy
session as anything more than "the transaction this use case runs in."
"""
