"""Wallet persistence.

`get_for_update` takes a `SELECT ... FOR UPDATE` row lock — this is the
mechanism the Phase 6 transaction engine relies on to serialise concurrent
operations against the same wallet and prevent double-spending. It's
introduced here, alongside the model, rather than bolted on later, so the
locking story is settled before any business logic depends on it.
"""
from typing import Protocol
from uuid import UUID

from sqlalchemy import select

from app.domain.entities.wallet import Wallet
from app.domain.repositories.base import SQLAlchemyRepository


class WalletRepository(Protocol):
    async def get_by_id(self, wallet_id: UUID) -> Wallet | None: ...
    async def get_by_user_id(self, user_id: UUID) -> Wallet | None: ...
    async def get_for_update(self, wallet_id: UUID) -> Wallet | None: ...
    def add(self, wallet: Wallet) -> None: ...


class SQLAlchemyWalletRepository(SQLAlchemyRepository[Wallet]):
    model = Wallet

    async def get_by_user_id(self, user_id: UUID) -> Wallet | None:
        result = await self._session.execute(
            select(Wallet).where(Wallet.user_id == user_id)
        )
        return result.scalar_one_or_none()

    async def get_for_update(self, wallet_id: UUID) -> Wallet | None:
        """Lock the wallet row for the duration of the current transaction.

        Callers must be inside an explicit transaction (i.e. not autocommit)
        for the lock to have any effect — see the Unit of Work in Phase 4.
        """
        result = await self._session.execute(
            select(Wallet).where(Wallet.id == wallet_id).with_for_update()
        )
        return result.scalar_one_or_none()
